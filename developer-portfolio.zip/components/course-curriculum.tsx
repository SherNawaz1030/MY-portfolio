import { Check } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

interface Module {
  title: string
  lessons: {
    title: string
    duration: string
  }[]
}

interface CourseCurriculumProps {
  modules: Module[]
}

export default function CourseCurriculum({ modules }: CourseCurriculumProps) {
  return (
    <div className="mt-8">
      <h3 className="text-2xl font-bold mb-6">Course Curriculum</h3>

      <Accordion type="single" collapsible className="w-full">
        {modules.map((module, index) => (
          <AccordionItem key={index} value={`module-${index}`}>
            <AccordionTrigger className="text-left font-medium">
              Module {index + 1}: {module.title}
            </AccordionTrigger>
            <AccordionContent>
              <ul className="space-y-3 pt-2">
                {module.lessons.map((lesson, lessonIndex) => (
                  <li key={lessonIndex} className="flex items-start">
                    <Check className="h-5 w-5 text-emerald-500 mr-2 mt-0.5 flex-shrink-0" />
                    <div className="flex justify-between w-full">
                      <span>{lesson.title}</span>
                      <span className="text-sm text-slate-500">{lesson.duration}</span>
                    </div>
                  </li>
                ))}
              </ul>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  )
}
