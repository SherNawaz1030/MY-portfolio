"use client"

import { Clock, Users, BarChart } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"

interface CourseCardProps {
  title: string
  description: string
  image: string
  price: string
  duration: string
  level: string
}

export default function CourseCard({ title, description, image, price, duration, level }: CourseCardProps) {
  return (
    <motion.div whileHover={{ y: -5 }} transition={{ duration: 0.2 }}>
      <Card className="overflow-hidden bg-slate-800 border-slate-700 hover:shadow-emerald-500/10 hover:shadow-lg transition-all duration-300 h-full">
        <div className="relative overflow-hidden h-48">
          <motion.img
            src={image || "/placeholder.svg"}
            alt={title}
            className="w-full h-full object-cover"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.5 }}
          />
          <div className="absolute top-3 right-3 bg-emerald-500 text-white px-3 py-1 rounded-full text-sm font-medium">
            {price}
          </div>
        </div>
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold mb-2 text-white">{title}</h3>
          <p className="text-slate-300 mb-4 line-clamp-2">{description}</p>

          <div className="flex flex-wrap gap-4 mb-6 text-slate-300 text-sm">
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1 text-emerald-400" />
              {duration}
            </div>
            <div className="flex items-center">
              <BarChart className="h-4 w-4 mr-1 text-emerald-400" />
              {level}
            </div>
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-1 text-emerald-400" />
              Limited Spots
            </div>
          </div>

          <Button className="w-full bg-emerald-500 hover:bg-emerald-600">Enroll Now</Button>
        </CardContent>
      </Card>
    </motion.div>
  )
}
