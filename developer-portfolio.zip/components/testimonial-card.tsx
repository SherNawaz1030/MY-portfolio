"use client"

import { Star } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { motion } from "framer-motion"

interface TestimonialCardProps {
  name: string
  role: string
  image: string
  testimonial: string
  rating: number
}

export default function TestimonialCard({ name, role, image, testimonial, rating }: TestimonialCardProps) {
  return (
    <motion.div whileHover={{ y: -5 }} transition={{ duration: 0.2 }}>
      <Card className="overflow-hidden hover:shadow-md transition-all duration-300 border-blue-100 dark:border-slate-700 h-full">
        <CardContent className="p-6">
          <div className="flex items-center mb-4">
            <img src={image || "/placeholder.svg"} alt={name} className="w-12 h-12 rounded-full object-cover mr-4" />
            <div>
              <h3 className="font-semibold text-blue-900 dark:text-white">{name}</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">{role}</p>
            </div>
          </div>

          <div className="flex mb-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${i < rating ? "text-amber-400 fill-amber-400" : "text-slate-300 dark:text-slate-600"}`}
              />
            ))}
          </div>

          <p className="text-slate-600 italic dark:text-slate-300">"{testimonial}"</p>
        </CardContent>
      </Card>
    </motion.div>
  )
}
