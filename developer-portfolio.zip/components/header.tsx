"use client"

import Link from "next/link"
import { useState } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import MainNav from "@/components/main-nav"
import ThemeToggle from "@/components/theme-toggle"
import { useAuth } from "@/context/auth-context"

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { user, logout } = useAuth()

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 bg-white/80 backdrop-blur-sm dark:border-slate-800 dark:bg-slate-900/80">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-xl font-bold text-slate-900 dark:text-white">
              Mustafa Dev
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <MainNav />
            <ThemeToggle />
            <div className="flex space-x-2 ml-4">
              {user ? (
                <>
                  <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                    <Link href="/admin/dashboard">Dashboard</Link>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-blue-500 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950"
                    onClick={() => logout()}
                  >
                    Logout
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-blue-500 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950"
                  >
                    <Link href="/login">Login</Link>
                  </Button>
                  <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                    <Link href="/register">Register</Link>
                  </Button>
                </>
              )}
            </div>
          </div>

          <div className="md:hidden flex items-center gap-2">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden">
          <div className="container mx-auto px-4 py-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
            <nav className="flex flex-col space-y-4">
              <Link
                href="/"
                className="text-sm font-medium hover:text-blue-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="/projects"
                className="text-sm font-medium hover:text-blue-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                Projects
              </Link>
              <Link
                href="/services"
                className="text-sm font-medium hover:text-blue-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                Services
              </Link>
              <Link
                href="/learn-skills"
                className="text-sm font-medium hover:text-blue-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                Learn Skills
              </Link>
              <Link
                href="/#contact"
                className="text-sm font-medium hover:text-blue-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                Contact
              </Link>
              <div className="flex space-x-2 pt-2">
                {user ? (
                  <>
                    <Button variant="outline" size="sm" className="border-blue-500 text-blue-500 w-full">
                      <Link href="/admin/dashboard" className="w-full">
                        Dashboard
                      </Link>
                    </Button>
                    <Button
                      size="sm"
                      className="bg-blue-500 hover:bg-blue-600 w-full"
                      onClick={() => {
                        logout()
                        setMobileMenuOpen(false)
                      }}
                    >
                      Logout
                    </Button>
                  </>
                ) : (
                  <>
                    <Button variant="outline" size="sm" className="border-blue-500 text-blue-500 w-full">
                      <Link href="/login" className="w-full" onClick={() => setMobileMenuOpen(false)}>
                        Login
                      </Link>
                    </Button>
                    <Button size="sm" className="bg-blue-500 hover:bg-blue-600 w-full">
                      <Link href="/register" className="w-full" onClick={() => setMobileMenuOpen(false)}>
                        Register
                      </Link>
                    </Button>
                  </>
                )}
              </div>
            </nav>
          </div>
        </div>
      )}
    </header>
  )
}
