"use client"

import { ArrowRight, Cpu, Database, Globe, Layers, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"
import Link from "next/link"

export default function ServicesPage() {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  }

  return (
    <main className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-slate-900 text-white py-20 dark:bg-black">
        <div className="container mx-auto px-4">
          <motion.h1
            className="text-4xl md:text-5xl font-bold mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            My Services
          </motion.h1>
          <motion.p
            className="text-xl text-slate-300 max-w-2xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Comprehensive development and consulting services to help you build innovative digital solutions.
          </motion.p>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 dark:bg-slate-950">
        <div className="container mx-auto px-4">
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={container}
            initial="hidden"
            animate="show"
          >
            <motion.div variants={item}>
              <Card className="border-slate-200 hover:shadow-md transition-shadow dark:border-slate-700 dark:bg-slate-800 h-full">
                <CardHeader className="pb-2">
                  <div className="bg-emerald-100 dark:bg-emerald-900/30 p-3 rounded-lg w-fit mb-4">
                    <Globe className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <CardTitle className="dark:text-white">Web Application Development</CardTitle>
                  <CardDescription className="dark:text-slate-400">
                    Modern, responsive web applications built with the latest technologies
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-slate-600 dark:text-slate-300">
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">•</span>
                      Single-page applications (SPAs)
                    </li>
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">•</span>
                      Progressive web apps (PWAs)
                    </li>
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">•</span>
                      E-commerce platforms
                    </li>
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">•</span>
                      Content management systems
                    </li>
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">•</span>
                      Custom web portals
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full dark:border-slate-600 dark:text-white">
                    Learn More
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>

            <motion.div variants={item}>
              <Card className="border-slate-200 hover:shadow-md transition-shadow dark:border-slate-700 dark:bg-slate-800 h-full">
                <CardHeader className="pb-2">
                  <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-lg w-fit mb-4">
                    <Cpu className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <CardTitle className="dark:text-white">AI Integration</CardTitle>
                  <CardDescription className="dark:text-slate-400">
                    Integrate cutting-edge AI capabilities into your applications
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-slate-600 dark:text-slate-300">
                    <li className="flex items-start">
                      <span className="text-blue-500 mr-2">•</span>
                      Generative AI implementation
                    </li>
                    <li className="flex items-start">
                      <span className="text-blue-500 mr-2">•</span>
                      Natural language processing
                    </li>
                    <li className="flex items-start">
                      <span className="text-blue-500 mr-2">•</span>
                      Computer vision solutions
                    </li>
                    <li className="flex items-start">
                      <span className="text-blue-500 mr-2">•</span>
                      Recommendation systems
                    </li>
                    <li className="flex items-start">
                      <span className="text-blue-500 mr-2">•</span>
                      Custom AI model training
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full dark:border-slate-600 dark:text-white">
                    Learn More
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>

            <motion.div variants={item}>
              <Card className="border-slate-200 hover:shadow-md transition-shadow dark:border-slate-700 dark:bg-slate-800 h-full">
                <CardHeader className="pb-2">
                  <div className="bg-amber-100 dark:bg-amber-900/30 p-3 rounded-lg w-fit mb-4">
                    <Layers className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                  </div>
                  <CardTitle className="dark:text-white">AI Agent Development</CardTitle>
                  <CardDescription className="dark:text-slate-400">
                    Build autonomous AI agents to automate tasks and solve problems
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-slate-600 dark:text-slate-300">
                    <li className="flex items-start">
                      <span className="text-amber-500 mr-2">•</span>
                      Autonomous agent architecture
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-500 mr-2">•</span>
                      Multi-agent systems
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-500 mr-2">•</span>
                      Task automation agents
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-500 mr-2">•</span>
                      Conversational AI agents
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-500 mr-2">•</span>
                      Custom agent development
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full dark:border-slate-600 dark:text-white">
                    Learn More
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>

            <motion.div variants={item}>
              <Card className="border-slate-200 hover:shadow-md transition-shadow dark:border-slate-700 dark:bg-slate-800 h-full">
                <CardHeader className="pb-2">
                  <div className="bg-red-100 dark:bg-red-900/30 p-3 rounded-lg w-fit mb-4">
                    <Database className="h-6 w-6 text-red-600 dark:text-red-400" />
                  </div>
                  <CardTitle className="dark:text-white">Backend Development</CardTitle>
                  <CardDescription className="dark:text-slate-400">
                    Robust, scalable backend systems and APIs
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-slate-600 dark:text-slate-300">
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">•</span>
                      RESTful API development
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">•</span>
                      GraphQL API development
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">•</span>
                      Database design and optimization
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">•</span>
                      Serverless architecture
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">•</span>
                      Microservices implementation
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full dark:border-slate-600 dark:text-white">
                    Learn More
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>

            <motion.div variants={item}>
              <Card className="border-slate-200 hover:shadow-md transition-shadow dark:border-slate-700 dark:bg-slate-800 h-full">
                <CardHeader className="pb-2">
                  <div className="bg-green-100 dark:bg-green-900/30 p-3 rounded-lg w-fit mb-4">
                    <Users className="h-6 w-6 text-green-600 dark:text-green-400" />
                  </div>
                  <CardTitle className="dark:text-white">Technical Training</CardTitle>
                  <CardDescription className="dark:text-slate-400">
                    Comprehensive training programs for individuals and teams
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-slate-600 dark:text-slate-300">
                    <li className="flex items-start">
                      <span className="text-green-500 mr-2">•</span>
                      Web development workshops
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-500 mr-2">•</span>
                      React and Next.js courses
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-500 mr-2">•</span>
                      AI and machine learning training
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-500 mr-2">•</span>
                      Custom team training programs
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-500 mr-2">•</span>
                      One-on-one mentoring
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full dark:border-slate-600 dark:text-white">
                    Learn More
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-slate-50 dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <motion.h2
            className="text-3xl font-bold mb-12 text-center dark:text-white"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            My Development Process
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-emerald-600 dark:text-emerald-400 text-xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 dark:text-white">Discovery</h3>
              <p className="text-slate-600 dark:text-slate-400">
                Understanding your requirements, goals, and vision for the project.
              </p>
            </motion.div>

            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-emerald-600 dark:text-emerald-400 text-xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 dark:text-white">Planning</h3>
              <p className="text-slate-600 dark:text-slate-400">
                Creating a detailed roadmap with milestones, technologies, and architecture.
              </p>
            </motion.div>

            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-emerald-600 dark:text-emerald-400 text-xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 dark:text-white">Development</h3>
              <p className="text-slate-600 dark:text-slate-400">
                Building your solution with regular updates and iterative improvements.
              </p>
            </motion.div>

            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-emerald-600 dark:text-emerald-400 text-xl font-bold">4</span>
              </div>
              <h3 className="text-xl font-semibold mb-2 dark:text-white">Delivery & Support</h3>
              <p className="text-slate-600 dark:text-slate-400">
                Launching your solution and providing ongoing maintenance and support.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-slate-900 text-white py-16 dark:bg-black">
        <div className="container mx-auto px-4 text-center">
          <motion.h2
            className="text-3xl font-bold mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Ready to start your project?
          </motion.h2>
          <motion.p
            className="text-slate-300 max-w-2xl mx-auto mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Let's discuss how I can help you achieve your goals with custom development solutions.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Link href="/#contact">
              <Button size="lg" className="bg-emerald-500 hover:bg-emerald-600">
                Get in Touch <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </main>
  )
}
