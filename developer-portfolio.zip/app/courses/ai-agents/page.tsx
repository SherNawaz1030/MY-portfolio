import { redirect } from "next/navigation"

export default function AIAgentsCoursePage() {
  redirect("/courses/ai-agents")
  return null
}
