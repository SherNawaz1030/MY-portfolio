import { redirect } from "next/navigation"

export default function GenerativeAICoursePage() {
  redirect("/courses/generative-ai")
  return null
}
