import { redirect } from "next/navigation"

export default function PythonCoursePage() {
  redirect("/courses/python")
  return null
}
