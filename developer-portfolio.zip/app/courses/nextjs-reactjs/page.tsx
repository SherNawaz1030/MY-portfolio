import { redirect } from "next/navigation"

export default function NextjsReactjsCoursePage() {
  redirect("/courses/nextjs-reactjs")
  return null
}
