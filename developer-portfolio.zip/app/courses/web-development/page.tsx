import { redirect } from "next/navigation"

export default function WebDevelopmentCoursePage() {
  redirect("/courses/web-development")
  return null
}
