import { redirect } from "next/navigation"

export default function VuejsCoursePage() {
  redirect("/courses/vuejs")
  return null
}
