"use client"

import Link from "next/link"
import { ArrowRight, BarChart, Clock, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import CourseCard from "@/components/course-card"
import WhatsAppButton from "@/components/whatsapp-button"

export default function CoursesPage() {
  const courses = [
    {
      title: "Web Development Fundamentals",
      description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
      image: "/placeholder.svg?height=200&width=350",
      price: "$79",
      duration: "4 weeks",
      level: "Beginner",
      slug: "web-development",
    },
    {
      title: "Next.js & React Masterclass",
      description: "Master React and Next.js to build modern, performant web applications.",
      image: "/placeholder.svg?height=200&width=350",
      price: "$99",
      duration: "8 weeks",
      level: "Intermediate",
      slug: "nextjs-reactjs",
    },
    {
      title: "Vue.js Development",
      description: "Learn Vue.js to build reactive, component-based web applications.",
      image: "/placeholder.svg?height=200&width=350",
      price: "$89",
      duration: "6 weeks",
      level: "Intermediate",
      slug: "vuejs",
    },
    {
      title: "Quasar Framework",
      description: "Build high-performance Vue.js applications with the Quasar Framework.",
      image: "/placeholder.svg?height=200&width=350",
      price: "$99",
      duration: "5 weeks",
      level: "Intermediate",
      slug: "quasar-framework",
    },
    {
      title: "Python Programming",
      description: "Learn Python for backend development, data analysis, and automation.",
      image: "/placeholder.svg?height=200&width=350",
      price: "$89",
      duration: "8 weeks",
      level: "Beginner to Intermediate",
      slug: "python",
    },
    {
      title: "AI Agent Development",
      description: "Build autonomous AI agents that can perform complex tasks and solve problems.",
      image: "/placeholder.svg?height=200&width=350",
      price: "$149",
      duration: "10 weeks",
      level: "Advanced",
      slug: "ai-agents",
    },
    {
      title: "Generative AI Integration",
      description: "Learn to integrate and fine-tune generative AI models in your applications.",
      image: "/placeholder.svg?height=200&width=350",
      price: "$129",
      duration: "8 weeks",
      level: "Advanced",
      slug: "generative-ai",
    },
  ]

  return (
    <main className="flex flex-col min-h-screen">
      {/* WhatsApp Button */}
      <WhatsAppButton phoneNumber="+1234567890" message="Hello! I have a question about your courses." />

      {/* Hero Section */}
      <section className="bg-slate-900 text-white py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Courses</h1>
          <p className="text-xl text-slate-300 max-w-2xl">
            Comprehensive courses designed to help you master modern development and AI skills.
          </p>
        </div>
      </section>

      {/* Courses Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course, index) => (
              <Link key={index} href={`/courses/${course.slug}`} className="block">
                <CourseCard
                  title={course.title}
                  description={course.description}
                  image={course.image}
                  price={course.price}
                  duration={course.duration}
                  level={course.level}
                />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why Learn With Me Section */}
      <section className="py-16 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Why Learn With Me</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Benefits of taking my courses and learning from my experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="bg-emerald-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6 text-emerald-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Industry Experience</h3>
              <p className="text-slate-600">
                Learn from a professional with real-world experience building applications for clients and companies.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="bg-blue-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Lifetime Access</h3>
              <p className="text-slate-600">
                Get lifetime access to course materials, updates, and future improvements.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="bg-purple-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <BarChart className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Project-Based Learning</h3>
              <p className="text-slate-600">
                Build real-world projects that you can add to your portfolio while learning new skills.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="bg-amber-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6 text-amber-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Community Support</h3>
              <p className="text-slate-600">
                Join a community of learners and get support from both peers and the instructor.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-slate-900 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to advance your skills?</h2>
          <p className="text-slate-300 max-w-2xl mx-auto mb-8">
            Choose a course and start your learning journey today.
          </p>
          <Button size="lg" className="bg-emerald-500 hover:bg-emerald-600">
            Get Started <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>
    </main>
  )
}
