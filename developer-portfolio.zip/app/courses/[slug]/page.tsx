"use client"

import Link from "next/link"
import { ArrowLeft, BarChart, BookOpen, Calendar, CheckCircle, Clock, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import CourseCurriculum from "@/components/course-curriculum"
import { motion } from "framer-motion"
import { useEffect } from "react"
import WhatsAppButton from "@/components/whatsapp-button"

interface CoursePageProps {
  params: {
    slug: string
  }
}

export default function CoursePage({ params }: CoursePageProps) {
  // This would typically come from a database or API
  const courseData = getCourseData(params.slug)

  // Scroll to top on page load
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [params.slug])

  if (!courseData) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-3xl font-bold mb-4 dark:text-white">Course Not Found</h1>
        <p className="mb-8 dark:text-slate-300">The course you're looking for doesn't exist.</p>
        <Link href="/courses">
          <Button>Back to Courses</Button>
        </Link>
      </div>
    )
  }

  return (
    <main className="flex flex-col min-h-screen dark:bg-slate-950">
      {/* WhatsApp Button */}
      <WhatsAppButton
        phoneNumber="+1234567890"
        message={`Hello! I have a question about the ${courseData.title} course.`}
      />

      {/* Hero Section */}
      <section className="bg-slate-900 text-white py-20 dark:bg-black">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.3 }}>
            <Link href="/courses" className="inline-flex items-center text-slate-300 hover:text-white mb-6">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Courses
            </Link>
          </motion.div>
          <motion.h1
            className="text-4xl md:text-5xl font-bold mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {courseData.title}
          </motion.h1>
          <motion.p
            className="text-xl text-slate-300 max-w-3xl mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            {courseData.description}
          </motion.p>
          <motion.div
            className="flex flex-wrap gap-6 mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center">
              <Clock className="h-5 w-5 mr-2 text-emerald-400" />
              <span>{courseData.duration}</span>
            </div>
            <div className="flex items-center">
              <BarChart className="h-5 w-5 mr-2 text-emerald-400" />
              <span>{courseData.level}</span>
            </div>
            <div className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-emerald-400" />
              <span>{courseData.students}+ Students</span>
            </div>
            <div className="flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-emerald-400" />
              <span>Last Updated: {courseData.lastUpdated}</span>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button size="lg" className="bg-emerald-500 hover:bg-emerald-600">
              Enroll Now for {courseData.price}
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Course Content Section */}
      <section className="py-16 dark:bg-slate-950">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-12">
            <motion.div
              className="lg:w-2/3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Tabs defaultValue="overview">
                <TabsList className="mb-8">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                  <TabsTrigger value="instructor">Instructor</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>

                <TabsContent value="overview">
                  <div>
                    <h2 className="text-2xl font-bold mb-6 dark:text-white">About This Course</h2>
                    <div className="prose max-w-none dark:prose-invert">
                      <p className="mb-4 dark:text-slate-300">{courseData.longDescription}</p>

                      <h3 className="text-xl font-semibold mt-8 mb-4 dark:text-white">What You'll Learn</h3>
                      <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {courseData.learningOutcomes.map((outcome, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-emerald-500 mr-2 mt-0.5 flex-shrink-0" />
                            <span className="dark:text-slate-300">{outcome}</span>
                          </li>
                        ))}
                      </ul>

                      <h3 className="text-xl font-semibold mt-8 mb-4 dark:text-white">Requirements</h3>
                      <ul className="space-y-2">
                        {courseData.requirements.map((req, index) => (
                          <li key={index} className="flex items-start">
                            <span className="text-emerald-500 mr-2">•</span>
                            <span className="dark:text-slate-300">{req}</span>
                          </li>
                        ))}
                      </ul>

                      <h3 className="text-xl font-semibold mt-8 mb-4 dark:text-white">Who This Course Is For</h3>
                      <ul className="space-y-2">
                        {courseData.targetAudience.map((audience, index) => (
                          <li key={index} className="flex items-start">
                            <span className="text-emerald-500 mr-2">•</span>
                            <span className="dark:text-slate-300">{audience}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="curriculum">
                  <CourseCurriculum modules={courseData.curriculum} />
                </TabsContent>

                <TabsContent value="instructor">
                  <div>
                    <h2 className="text-2xl font-bold mb-6 dark:text-white">Your Instructor</h2>
                    <div className="flex items-start gap-6 mb-8">
                      <img
                        src="/placeholder.svg?height=150&width=150"
                        alt="Instructor"
                        className="w-24 h-24 rounded-full object-cover"
                      />
                      <div>
                        <h3 className="text-xl font-semibold dark:text-white">Mustafa</h3>
                        <p className="text-slate-600 dark:text-slate-400 mb-4">Professional Developer & Educator</p>
                        <p className="mb-4 dark:text-slate-300">
                          With over 10 years of experience in web and AI development, I've worked with startups and
                          Fortune 500 companies to build scalable, user-friendly applications. I'm passionate about
                          teaching and helping others develop their technical skills.
                        </p>
                        <div className="flex gap-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-emerald-600">10+</div>
                            <div className="text-sm text-slate-600 dark:text-slate-400">Years Experience</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-emerald-600">50+</div>
                            <div className="text-sm text-slate-600 dark:text-slate-400">Projects Completed</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-emerald-600">5,000+</div>
                            <div className="text-sm text-slate-600 dark:text-slate-400">Students Taught</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="reviews">
                  <div>
                    <h2 className="text-2xl font-bold mb-6 dark:text-white">Student Reviews</h2>
                    <div className="flex items-center mb-8">
                      <div className="text-5xl font-bold mr-6 dark:text-white">4.8</div>
                      <div>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <svg key={star} className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 24 24">
                              <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                            </svg>
                          ))}
                        </div>
                        <p className="text-slate-600 dark:text-slate-400">Based on {courseData.reviewCount} reviews</p>
                      </div>
                    </div>

                    <div className="space-y-6">
                      {courseData.reviews.map((review, index) => (
                        <div key={index} className="border-b border-slate-200 dark:border-slate-700 pb-6">
                          <div className="flex items-center mb-2">
                            <img
                              src={review.avatar || "/placeholder.svg?height=50&width=50"}
                              alt={review.name}
                              className="w-10 h-10 rounded-full mr-3"
                            />
                            <div>
                              <h4 className="font-medium dark:text-white">{review.name}</h4>
                              <div className="flex">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <svg
                                    key={star}
                                    className={`w-4 h-4 ${star <= review.rating ? "text-yellow-400" : "text-slate-300 dark:text-slate-600"} fill-current`}
                                    viewBox="0 0 24 24"
                                  >
                                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                                  </svg>
                                ))}
                              </div>
                            </div>
                          </div>
                          <p className="text-slate-600 dark:text-slate-300">{review.comment}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </motion.div>

            <motion.div
              className="lg:w-1/3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden sticky top-24">
                <img
                  src={courseData.image || "/placeholder.svg?height=300&width=500"}
                  alt={courseData.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="text-3xl font-bold mb-4 dark:text-white">{courseData.price}</div>

                  <div className="space-y-4 mb-6">
                    <div className="flex items-center">
                      <BookOpen className="h-5 w-5 text-slate-500 dark:text-slate-400 mr-3" />
                      <span className="dark:text-slate-300">
                        {courseData.curriculum.reduce((acc, module) => acc + module.lessons.length, 0)} lessons
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-slate-500 dark:text-slate-400 mr-3" />
                      <span className="dark:text-slate-300">{courseData.duration}</span>
                    </div>
                    <div className="flex items-center">
                      <Users className="h-5 w-5 text-slate-500 dark:text-slate-400 mr-3" />
                      <span className="dark:text-slate-300">Access on mobile and desktop</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-slate-500 dark:text-slate-400 mr-3" />
                      <span className="dark:text-slate-300">Certificate of completion</span>
                    </div>
                  </div>

                  <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
                    <Button className="w-full bg-emerald-500 hover:bg-emerald-600 mb-4">Enroll Now</Button>
                  </motion.div>

                  <p className="text-center text-sm text-slate-500 dark:text-slate-400">30-day money-back guarantee</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Related Courses Section */}
      <section className="py-16 bg-slate-50 dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <motion.h2
            className="text-3xl font-bold mb-8 dark:text-white"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Related Courses
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {courseData.relatedCourses.map((course, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <Link href={`/courses/${course.slug}`} className="block">
                  <div className="bg-white dark:bg-slate-800 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow h-full">
                    <img
                      src={course.image || "/placeholder.svg?height=200&width=350"}
                      alt={course.title}
                      className="w-full h-40 object-cover"
                    />
                    <div className="p-6">
                      <h3 className="text-xl font-semibold mb-2 dark:text-white">{course.title}</h3>
                      <p className="text-slate-600 dark:text-slate-300 mb-4 line-clamp-2">{course.description}</p>
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-emerald-600">{course.price}</span>
                        <div className="flex items-center text-sm text-slate-500 dark:text-slate-400">
                          <Clock className="h-4 w-4 mr-1" />
                          {course.duration}
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}

// This would typically come from a database or API
function getCourseData(slug: string) {
  const courses = {
    "web-development": {
      title: "Web Development Fundamentals",
      description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
      longDescription:
        "This comprehensive course will take you from a complete beginner to a confident web developer. You'll learn the core technologies that power the web: HTML for structure, CSS for styling, and JavaScript for interactivity. Through hands-on projects and practical exercises, you'll build a strong foundation in web development principles and best practices that will serve as the basis for more advanced frameworks and libraries.",
      image: "/placeholder.svg?height=300&width=500",
      price: "$79",
      duration: "4 weeks",
      level: "Beginner",
      students: 1250,
      lastUpdated: "May 2025",
      learningOutcomes: [
        "Build responsive websites using HTML5 and CSS3",
        "Create interactive web pages with JavaScript",
        "Understand web development fundamentals and best practices",
        "Implement responsive design principles for mobile and desktop",
        "Use developer tools to debug and optimize websites",
        "Deploy websites to hosting platforms",
      ],
      requirements: [
        "No prior programming experience required",
        "Basic computer skills",
        "A computer with internet access",
        "Enthusiasm to learn and practice",
      ],
      targetAudience: [
        "Beginners with no prior coding experience",
        "Designers looking to expand their skills",
        "Anyone interested in learning web development",
        "Students preparing for more advanced web technologies",
      ],
      curriculum: [
        {
          title: "Introduction to HTML",
          lessons: [
            { title: "Web Development Overview", duration: "15 min" },
            { title: "HTML Document Structure", duration: "25 min" },
            { title: "Text Elements and Formatting", duration: "30 min" },
            { title: "Links and Navigation", duration: "20 min" },
            { title: "Images and Media", duration: "25 min" },
            { title: "Tables and Lists", duration: "30 min" },
            { title: "Forms and Input Elements", duration: "35 min" },
          ],
        },
        {
          title: "CSS Fundamentals",
          lessons: [
            { title: "Introduction to CSS", duration: "20 min" },
            { title: "Selectors and Properties", duration: "30 min" },
            { title: "Box Model and Layout", duration: "35 min" },
            { title: "Colors and Typography", duration: "25 min" },
            { title: "Flexbox Layout", duration: "40 min" },
            { title: "CSS Grid Layout", duration: "45 min" },
            { title: "Responsive Design Principles", duration: "35 min" },
          ],
        },
        {
          title: "JavaScript Basics",
          lessons: [
            { title: "Introduction to JavaScript", duration: "25 min" },
            { title: "Variables and Data Types", duration: "30 min" },
            { title: "Operators and Expressions", duration: "25 min" },
            { title: "Control Flow: Conditionals", duration: "35 min" },
            { title: "Control Flow: Loops", duration: "30 min" },
            { title: "Functions and Scope", duration: "40 min" },
            { title: "DOM Manipulation Basics", duration: "45 min" },
          ],
        },
        {
          title: "Building a Complete Website",
          lessons: [
            { title: "Project Planning and Setup", duration: "20 min" },
            { title: "Creating the HTML Structure", duration: "35 min" },
            { title: "Styling with CSS", duration: "40 min" },
            { title: "Adding Interactivity with JavaScript", duration: "45 min" },
            { title: "Responsive Design Implementation", duration: "35 min" },
            { title: "Testing and Debugging", duration: "30 min" },
            { title: "Deployment and Publishing", duration: "25 min" },
          ],
        },
      ],
      reviewCount: 128,
      reviews: [
        {
          name: "Sarah Johnson",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "This course was exactly what I needed as a complete beginner. The instructor explains everything clearly and the projects helped me apply what I learned.",
        },
        {
          name: "Michael Chen",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 4,
          comment:
            "Great introduction to web development. I feel confident in my HTML and CSS skills now, though I wish there was a bit more JavaScript content.",
        },
        {
          name: "Jessica Williams",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "The step-by-step approach made learning easy. I went from knowing nothing about coding to building my own portfolio website!",
        },
      ],
      relatedCourses: [
        {
          title: "Next.js & React Masterclass",
          description: "Master React and Next.js to build modern, performant web applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$99",
          duration: "8 weeks",
          slug: "nextjs-reactjs",
        },
        {
          title: "Vue.js Development",
          description: "Learn Vue.js to build reactive, component-based web applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$89",
          duration: "6 weeks",
          slug: "vuejs",
        },
        {
          title: "Python Programming",
          description: "Learn Python for backend development, data analysis, and automation.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$89",
          duration: "8 weeks",
          slug: "python",
        },
      ],
    },
    "nextjs-reactjs": {
      title: "Next.js & React Masterclass",
      description: "Master React and Next.js to build modern, performant web applications.",
      longDescription:
        "Take your web development skills to the next level with this comprehensive course on React and Next.js. You'll learn how to build modern, performant web applications using React's component-based architecture and Next.js's powerful features like server-side rendering, API routes, and more. By the end of this course, you'll be able to create professional-grade web applications that are fast, scalable, and maintainable.",
      image: "/placeholder.svg?height=300&width=500",
      price: "$99",
      duration: "8 weeks",
      level: "Intermediate",
      students: 950,
      lastUpdated: "April 2025",
      learningOutcomes: [
        "Build modern web applications with React and Next.js",
        "Implement server-side rendering and static site generation",
        "Create and consume API routes in Next.js",
        "Manage state effectively in React applications",
        "Implement authentication and authorization",
        "Deploy Next.js applications to production",
      ],
      requirements: [
        "Basic knowledge of HTML, CSS, and JavaScript",
        "Understanding of ES6+ features",
        "Familiarity with npm and package management",
        "A computer with Node.js installed",
      ],
      targetAudience: [
        "Web developers looking to level up their skills",
        "Frontend developers wanting to learn React and Next.js",
        "Developers transitioning from other frameworks",
        "Students who have completed a web development basics course",
      ],
      curriculum: [
        {
          title: "React Fundamentals",
          lessons: [
            { title: "Introduction to React", duration: "30 min" },
            { title: "Components and Props", duration: "45 min" },
            { title: "State and Lifecycle", duration: "40 min" },
            { title: "Handling Events", duration: "35 min" },
            { title: "Conditional Rendering", duration: "30 min" },
            { title: "Lists and Keys", duration: "35 min" },
            { title: "Forms and Controlled Components", duration: "45 min" },
          ],
        },
        {
          title: "React Hooks",
          lessons: [
            { title: "Introduction to Hooks", duration: "25 min" },
            { title: "useState Hook", duration: "40 min" },
            { title: "useEffect Hook", duration: "45 min" },
            { title: "useContext Hook", duration: "35 min" },
            { title: "useRef Hook", duration: "30 min" },
            { title: "Custom Hooks", duration: "50 min" },
            { title: "Rules of Hooks", duration: "25 min" },
          ],
        },
        {
          title: "Next.js Fundamentals",
          lessons: [
            { title: "Introduction to Next.js", duration: "30 min" },
            { title: "Pages and Routing", duration: "40 min" },
            { title: "Data Fetching Methods", duration: "45 min" },
            { title: "Static Site Generation (SSG)", duration: "40 min" },
            { title: "Server-Side Rendering (SSR)", duration: "40 min" },
            { title: "API Routes", duration: "35 min" },
            { title: "Styling in Next.js", duration: "30 min" },
          ],
        },
        {
          title: "Building a Full Next.js Application",
          lessons: [
            { title: "Project Setup and Structure", duration: "25 min" },
            { title: "Authentication Implementation", duration: "50 min" },
            { title: "Database Integration", duration: "45 min" },
            { title: "Creating API Endpoints", duration: "40 min" },
            { title: "Building the Frontend", duration: "55 min" },
            { title: "Testing and Optimization", duration: "40 min" },
            { title: "Deployment to Vercel", duration: "30 min" },
          ],
        },
      ],
      reviewCount: 95,
      reviews: [
        {
          name: "David Kim",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "This course transformed my understanding of modern web development. The Next.js content is particularly valuable and up-to-date.",
        },
        {
          name: "Emily Rodriguez",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "Excellent course! I was able to build and deploy a production-ready application by following along with the projects.",
        },
        {
          name: "Alex Thompson",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 4,
          comment:
            "Great content and well-explained concepts. The only reason I'm not giving 5 stars is that I wish there was more content on state management libraries.",
        },
      ],
      relatedCourses: [
        {
          title: "Web Development Fundamentals",
          description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$79",
          duration: "4 weeks",
          slug: "web-development",
        },
        {
          title: "Vue.js Development",
          description: "Learn Vue.js to build reactive, component-based web applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$89",
          duration: "6 weeks",
          slug: "vuejs",
        },
        {
          title: "AI Agent Development",
          description: "Build autonomous AI agents that can perform complex tasks and solve problems.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$149",
          duration: "10 weeks",
          slug: "ai-agents",
        },
      ],
    },
    vuejs: {
      title: "Vue.js Development",
      description: "Learn Vue.js to build reactive, component-based web applications.",
      longDescription:
        "This course provides a comprehensive introduction to Vue.js, one of the most popular JavaScript frameworks for building user interfaces. You'll learn Vue's core concepts including components, directives, and reactivity system, as well as more advanced topics like Vuex for state management and Vue Router for single-page applications. Through hands-on projects, you'll gain the skills to build sophisticated, reactive web applications.",
      image: "/placeholder.svg?height=300&width=500",
      price: "$89",
      duration: "6 weeks",
      level: "Intermediate",
      students: 780,
      lastUpdated: "March 2025",
      learningOutcomes: [
        "Build reactive web applications with Vue.js",
        "Create and compose Vue components",
        "Implement state management with Vuex",
        "Create single-page applications with Vue Router",
        "Use Vue CLI for project scaffolding and development",
        "Integrate Vue with backend APIs",
      ],
      requirements: [
        "Basic knowledge of HTML, CSS, and JavaScript",
        "Understanding of ES6+ features",
        "Familiarity with npm and package management",
        "A computer with Node.js installed",
      ],
      targetAudience: [
        "Web developers looking to learn a modern JavaScript framework",
        "React or Angular developers wanting to learn Vue.js",
        "Frontend developers seeking to expand their skill set",
        "Web development students with basic JavaScript knowledge",
      ],
      curriculum: [
        {
          title: "Vue.js Fundamentals",
          lessons: [
            { title: "Introduction to Vue.js", duration: "30 min" },
            { title: "Vue Instance and Data Binding", duration: "40 min" },
            { title: "Directives and Event Handling", duration: "45 min" },
            { title: "Computed Properties and Watchers", duration: "35 min" },
            { title: "Class and Style Bindings", duration: "30 min" },
            { title: "Conditional Rendering", duration: "25 min" },
            { title: "List Rendering", duration: "35 min" },
          ],
        },
        {
          title: "Components in Vue",
          lessons: [
            { title: "Component Basics", duration: "40 min" },
            { title: "Component Registration", duration: "30 min" },
            { title: "Props and Custom Events", duration: "45 min" },
            { title: "Slots and Scoped Slots", duration: "40 min" },
            { title: "Dynamic Components", duration: "35 min" },
            { title: "Async Components", duration: "30 min" },
            { title: "Component Composition", duration: "45 min" },
          ],
        },
        {
          title: "Vue Router and State Management",
          lessons: [
            { title: "Introduction to Vue Router", duration: "35 min" },
            { title: "Route Configuration", duration: "40 min" },
            { title: "Navigation Guards", duration: "35 min" },
            { title: "Nested Routes", duration: "30 min" },
            { title: "Introduction to Vuex", duration: "40 min" },
            { title: "State, Getters, Mutations, and Actions", duration: "50 min" },
            { title: "Modules and Organization", duration: "45 min" },
          ],
        },
        {
          title: "Building a Complete Vue Application",
          lessons: [
            { title: "Project Setup with Vue CLI", duration: "25 min" },
            { title: "Application Structure and Organization", duration: "30 min" },
            { title: "Implementing Authentication", duration: "45 min" },
            { title: "API Integration", duration: "40 min" },
            { title: "Building the UI Components", duration: "50 min" },
            { title: "Testing Vue Components", duration: "35 min" },
            { title: "Deployment and Optimization", duration: "30 min" },
          ],
        },
      ],
      reviewCount: 85,
      reviews: [
        {
          name: "Ryan Martinez",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "Vue.js is so intuitive, and this course does an excellent job of explaining the concepts. I was able to start building real applications right away.",
        },
        {
          name: "Sophia Lee",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 4,
          comment:
            "Great introduction to Vue. The projects were practical and helped solidify my understanding of the framework.",
        },
        {
          name: "James Wilson",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "Coming from React, I found Vue refreshingly simple to learn through this course. The instructor explains everything clearly and the pace is perfect.",
        },
      ],
      relatedCourses: [
        {
          title: "Web Development Fundamentals",
          description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$79",
          duration: "4 weeks",
          slug: "web-development",
        },
        {
          title: "Quasar Framework",
          description: "Build high-performance Vue.js applications with the Quasar Framework.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$99",
          duration: "5 weeks",
          slug: "quasar-framework",
        },
        {
          title: "Next.js & React Masterclass",
          description: "Master React and Next.js to build modern, performant web applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$99",
          duration: "8 weeks",
          slug: "nextjs-reactjs",
        },
      ],
    },
    "quasar-framework": {
      title: "Quasar Framework",
      description: "Build high-performance Vue.js applications with the Quasar Framework.",
      longDescription:
        "Take your Vue.js development to the next level with the Quasar Framework. This course teaches you how to build high-performance, responsive applications that work across multiple platforms including web, mobile, and desktop. You'll learn how to leverage Quasar's rich component library, build system, and CLI to create professional applications with minimal effort. By the end of this course, you'll be able to build and deploy applications for multiple platforms from a single codebase.",
      image: "/placeholder.svg?height=300&width=500",
      price: "$99",
      duration: "5 weeks",
      level: "Intermediate",
      students: 420,
      lastUpdated: "February 2025",
      learningOutcomes: [
        "Build cross-platform applications with Quasar Framework",
        "Create responsive UIs using Quasar's component library",
        "Implement mobile applications with Cordova integration",
        "Build desktop applications with Electron",
        "Use Quasar CLI for efficient development workflows",
        "Deploy Quasar applications to various platforms",
      ],
      requirements: [
        "Basic knowledge of Vue.js",
        "Understanding of HTML, CSS, and JavaScript",
        "Familiarity with npm and package management",
        "A computer with Node.js installed",
      ],
      targetAudience: [
        "Vue.js developers looking to expand their skills",
        "Developers interested in cross-platform development",
        "Frontend developers wanting to build mobile and desktop apps",
        "Web developers seeking efficient UI development workflows",
      ],
      curriculum: [
        {
          title: "Getting Started with Quasar",
          lessons: [
            { title: "Introduction to Quasar Framework", duration: "30 min" },
            { title: "Setting Up the Development Environment", duration: "25 min" },
            { title: "Quasar CLI and Project Structure", duration: "35 min" },
            { title: "Quasar App Configuration", duration: "30 min" },
            { title: "Understanding Quasar Boot Files", duration: "25 min" },
            { title: "Quasar's CSS Variables and Theming", duration: "40 min" },
            { title: "Responsive Design with Quasar", duration: "35 min" },
          ],
        },
        {
          title: "Quasar Components and Plugins",
          lessons: [
            { title: "Layout Components", duration: "40 min" },
            { title: "Form Components", duration: "45 min" },
            { title: "Navigation Components", duration: "35 min" },
            { title: "Data Presentation Components", duration: "40 min" },
            { title: "Quasar Plugins Overview", duration: "30 min" },
            { title: "Notifications and Dialogs", duration: "35 min" },
            { title: "LocalStorage and Cookies", duration: "30 min" },
          ],
        },
        {
          title: "Cross-Platform Development",
          lessons: [
            { title: "Building for Web (SPA, PWA, SSR)", duration: "45 min" },
            { title: "Introduction to Cordova Integration", duration: "40 min" },
            { title: "Building Mobile Applications", duration: "50 min" },
            { title: "Introduction to Electron Integration", duration: "40 min" },
            { title: "Building Desktop Applications", duration: "50 min" },
            { title: "Platform Detection and Adaptation", duration: "35 min" },
            { title: "Managing Platform-Specific Code", duration: "40 min" },
          ],
        },
        {
          title: "Building a Complete Quasar Application",
          lessons: [
            { title: "Project Planning and Setup", duration: "25 min" },
            { title: "Implementing the UI Components", duration: "50 min" },
            { title: "State Management with Vuex", duration: "45 min" },
            { title: "API Integration", duration: "40 min" },
            { title: "Building for Multiple Platforms", duration: "55 min" },
            { title: "Testing and Optimization", duration: "35 min" },
            { title: "Deployment Strategies", duration: "30 min" },
          ],
        },
      ],
      reviewCount: 45,
      reviews: [
        {
          name: "Thomas Brown",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "Quasar is a game-changer for Vue developers, and this course covers everything you need to know. I'm now building apps for web, iOS, and Android from a single codebase!",
        },
        {
          name: "Lisa Garcia",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 4,
          comment:
            "Great course that saved me tons of development time. The component library is extensive and this course shows you how to use it effectively.",
        },
        {
          name: "Kevin Taylor",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "As a Vue developer, learning Quasar through this course has been incredibly valuable. The cross-platform capabilities are impressive and well-explained.",
        },
      ],
      relatedCourses: [
        {
          title: "Vue.js Development",
          description: "Learn Vue.js to build reactive, component-based web applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$89",
          duration: "6 weeks",
          slug: "vuejs",
        },
        {
          title: "Next.js & React Masterclass",
          description: "Master React and Next.js to build modern, performant web applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$99",
          duration: "8 weeks",
          slug: "nextjs-reactjs",
        },
        {
          title: "Web Development Fundamentals",
          description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$79",
          duration: "4 weeks",
          slug: "web-development",
        },
      ],
    },
    python: {
      title: "Python Programming",
      description: "Learn Python for backend development, data analysis, and automation.",
      longDescription:
        "This comprehensive Python course takes you from the basics to advanced concepts, preparing you for various Python applications including backend development, data analysis, and automation. You'll learn core Python syntax, object-oriented programming, working with databases, web development with Flask, and data analysis with popular libraries. By the end of this course, you'll have the skills to build robust Python applications and automate tasks efficiently.",
      image: "/placeholder.svg?height=300&width=500",
      price: "$89",
      duration: "8 weeks",
      level: "Beginner to Intermediate",
      students: 1100,
      lastUpdated: "April 2025",
      learningOutcomes: [
        "Master Python syntax and programming concepts",
        "Build backend applications with Python",
        "Work with databases using SQLAlchemy",
        "Develop web applications with Flask",
        "Analyze data using pandas and NumPy",
        "Automate tasks with Python scripts",
      ],
      requirements: [
        "No prior programming experience required (though helpful)",
        "Basic computer skills",
        "A computer with internet access",
        "Enthusiasm to learn and practice",
      ],
      targetAudience: [
        "Beginners looking to learn programming",
        "Web developers wanting to learn backend development",
        "Data analysts seeking to automate workflows",
        "Professionals looking to enhance their technical skills",
      ],
      curriculum: [
        {
          title: "Python Fundamentals",
          lessons: [
            { title: "Introduction to Python", duration: "30 min" },
            { title: "Variables and Data Types", duration: "40 min" },
            { title: "Control Flow: Conditionals", duration: "35 min" },
            { title: "Control Flow: Loops", duration: "35 min" },
            { title: "Functions and Modules", duration: "45 min" },
            { title: "Working with Files", duration: "40 min" },
            { title: "Error Handling", duration: "35 min" },
          ],
        },
        {
          title: "Data Structures and OOP",
          lessons: [
            { title: "Lists and Tuples", duration: "40 min" },
            { title: "Dictionaries and Sets", duration: "40 min" },
            { title: "List Comprehensions", duration: "30 min" },
            { title: "Introduction to OOP", duration: "45 min" },
            { title: "Classes and Objects", duration: "50 min" },
            { title: "Inheritance and Polymorphism", duration: "45 min" },
            { title: "Advanced OOP Concepts", duration: "40 min" },
          ],
        },
        {
          title: "Python for Web Development",
          lessons: [
            { title: "Introduction to Flask", duration: "35 min" },
            { title: "Routing and Views", duration: "40 min" },
            { title: "Templates with Jinja2", duration: "45 min" },
            { title: "Working with Forms", duration: "40 min" },
            { title: "Database Integration with SQLAlchemy", duration: "50 min" },
            { title: "RESTful API Development", duration: "45 min" },
            { title: "Authentication and Authorization", duration: "50 min" },
          ],
        },
        {
          title: "Data Analysis and Automation",
          lessons: [
            { title: "Introduction to NumPy", duration: "40 min" },
            { title: "Data Analysis with pandas", duration: "50 min" },
            { title: "Data Visualization with Matplotlib", duration: "45 min" },
            { title: "Web Scraping with Beautiful Soup", duration: "40 min" },
            { title: "Automating Tasks with Python", duration: "45 min" },
            { title: "Working with APIs", duration: "40 min" },
            { title: "Building a Complete Python Project", duration: "60 min" },
          ],
        },
      ],
      reviewCount: 110,
      reviews: [
        {
          name: "Jennifer Adams",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "This course made Python accessible and fun to learn. The practical examples helped me understand how to apply Python in real-world scenarios.",
        },
        {
          name: "Robert Chen",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "Excellent course for beginners. I had no programming experience, but now I'm confidently writing Python scripts to automate my daily tasks.",
        },
        {
          name: "Maria Rodriguez",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 4,
          comment:
            "Great introduction to Python with a good balance of theory and practice. I especially enjoyed the data analysis section.",
        },
      ],
      relatedCourses: [
        {
          title: "AI Agent Development",
          description: "Build autonomous AI agents that can perform complex tasks and solve problems.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$149",
          duration: "10 weeks",
          slug: "ai-agents",
        },
        {
          title: "Generative AI Integration",
          description: "Learn to integrate and fine-tune generative AI models in your applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$129",
          duration: "8 weeks",
          slug: "generative-ai",
        },
        {
          title: "Web Development Fundamentals",
          description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$79",
          duration: "4 weeks",
          slug: "web-development",
        },
      ],
    },
    "ai-agents": {
      title: "AI Agent Development",
      description: "Build autonomous AI agents that can perform complex tasks and solve problems.",
      longDescription:
        "This advanced course teaches you how to build autonomous AI agents that can perform complex tasks, make decisions, and solve real-world problems. You'll learn about agent architectures, large language model integration, tool use, memory systems, and multi-agent coordination. Through hands-on projects, you'll develop practical skills for creating intelligent agents that can automate processes, assist users, and handle complex workflows.",
      image: "/placeholder.svg?height=300&width=500",
      price: "$149",
      duration: "10 weeks",
      level: "Advanced",
      students: 350,
      lastUpdated: "May 2025",
      learningOutcomes: [
        "Design and implement autonomous AI agents",
        "Integrate large language models (LLMs) into agent systems",
        "Implement tool use and function calling capabilities",
        "Create memory systems for persistent agent knowledge",
        "Develop multi-agent systems for complex tasks",
        "Deploy AI agents in production environments",
      ],
      requirements: [
        "Intermediate Python programming skills",
        "Basic understanding of AI and machine learning concepts",
        "Familiarity with APIs and web services",
        "A computer with Python 3.8+ installed",
      ],
      targetAudience: [
        "Software developers interested in AI automation",
        "AI engineers looking to build autonomous systems",
        "Data scientists wanting to create intelligent agents",
        "Professionals seeking to implement AI solutions",
      ],
      curriculum: [
        {
          title: "Foundations of AI Agents",
          lessons: [
            { title: "Introduction to AI Agents", duration: "35 min" },
            { title: "Agent Architectures and Design Patterns", duration: "45 min" },
            { title: "Decision Making in Agents", duration: "40 min" },
            { title: "Planning and Problem Solving", duration: "50 min" },
            { title: "Agent Communication", duration: "40 min" },
            { title: "Environment Interaction", duration: "45 min" },
            { title: "Ethical Considerations in Agent Design", duration: "35 min" },
          ],
        },
        {
          title: "LLM Integration and Tool Use",
          lessons: [
            { title: "Introduction to Large Language Models", duration: "40 min" },
            { title: "Prompt Engineering for Agents", duration: "45 min" },
            { title: "Function Calling with LLMs", duration: "50 min" },
            { title: "Tool Use Implementation", duration: "55 min" },
            { title: "API Integration", duration: "45 min" },
            { title: "Handling Tool Execution", duration: "40 min" },
            { title: "Error Handling and Fallbacks", duration: "35 min" },
          ],
        },
        {
          title: "Agent Memory and Learning",
          lessons: [
            { title: "Short-term and Working Memory", duration: "40 min" },
            { title: "Long-term Memory Systems", duration: "45 min" },
            { title: "Vector Databases for Knowledge Storage", duration: "50 min" },
            { title: "Retrieval Augmented Generation", duration: "55 min" },
            { title: "Learning from Feedback", duration: "45 min" },
            { title: "Adaptive Behavior", duration: "40 min" },
            { title: "Continuous Improvement Strategies", duration: "45 min" },
          ],
        },
        {
          title: "Multi-agent Systems and Deployment",
          lessons: [
            { title: "Introduction to Multi-agent Systems", duration: "40 min" },
            { title: "Agent Coordination and Collaboration", duration: "50 min" },
            { title: "Specialized Agent Roles", duration: "45 min" },
            { title: "Agent Supervision and Oversight", duration: "40 min" },
            { title: "Deploying Agents in Production", duration: "55 min" },
            { title: "Monitoring and Maintenance", duration: "40 min" },
            { title: "Building a Complete Agent System", duration: "60 min" },
          ],
        },
      ],
      reviewCount: 35,
      reviews: [
        {
          name: "Daniel Park",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "This course is cutting-edge and incredibly practical. I've been able to implement AI agents that have automated several workflows in my company.",
        },
        {
          name: "Olivia Johnson",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 4,
          comment:
            "Excellent content on a complex topic. The instructor breaks down difficult concepts into manageable pieces. The projects are challenging but rewarding.",
        },
        {
          name: "Marcus Williams",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "As an AI engineer, this course has been invaluable. The multi-agent system section in particular has transformed how I approach complex AI problems.",
        },
      ],
      relatedCourses: [
        {
          title: "Generative AI Integration",
          description: "Learn to integrate and fine-tune generative AI models in your applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$129",
          duration: "8 weeks",
          slug: "generative-ai",
        },
        {
          title: "Python Programming",
          description: "Learn Python for backend development, data analysis, and automation.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$89",
          duration: "8 weeks",
          slug: "python",
        },
        {
          title: "Next.js & React Masterclass",
          description: "Master React and Next.js to build modern, performant web applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$99",
          duration: "8 weeks",
          slug: "nextjs-reactjs",
        },
      ],
    },
    "generative-ai": {
      title: "Generative AI Integration",
      description: "Learn to integrate and fine-tune generative AI models in your applications.",
      longDescription:
        "This advanced course teaches you how to effectively integrate generative AI models into your applications. You'll learn about different types of generative models, prompt engineering techniques, fine-tuning strategies, and best practices for deployment. Through practical projects, you'll gain hands-on experience with text, image, and multimodal AI models, enabling you to build sophisticated AI-powered applications that can generate content, assist users, and solve complex problems.",
      image: "/placeholder.svg?height=300&width=500",
      price: "$129",
      duration: "8 weeks",
      level: "Advanced",
      students: 420,
      lastUpdated: "May 2025",
      learningOutcomes: [
        "Integrate generative AI models into applications",
        "Master prompt engineering techniques",
        "Fine-tune models for specific use cases",
        "Build applications with text, image, and multimodal AI",
        "Implement responsible AI practices",
        "Deploy generative AI solutions to production",
      ],
      requirements: [
        "Intermediate programming skills (Python preferred)",
        "Basic understanding of machine learning concepts",
        "Familiarity with web development",
        "A computer with Python 3.8+ installed",
      ],
      targetAudience: [
        "Software developers wanting to integrate AI capabilities",
        "Product managers overseeing AI features",
        "AI engineers looking to expand their generative AI skills",
        "Entrepreneurs building AI-powered products",
      ],
      curriculum: [
        {
          title: "Foundations of Generative AI",
          lessons: [
            { title: "Introduction to Generative AI", duration: "35 min" },
            { title: "Types of Generative Models", duration: "45 min" },
            { title: "Large Language Models Overview", duration: "40 min" },
            { title: "Image Generation Models", duration: "40 min" },
            { title: "Multimodal AI Models", duration: "45 min" },
            { title: "Generative AI Capabilities and Limitations", duration: "35 min" },
            { title: "Ethical Considerations", duration: "30 min" },
          ],
        },
        {
          title: "Prompt Engineering and Integration",
          lessons: [
            { title: "Fundamentals of Prompt Engineering", duration: "45 min" },
            { title: "Advanced Prompting Techniques", duration: "50 min" },
            { title: "Few-shot and Zero-shot Learning", duration: "40 min" },
            { title: "Chain of Thought Prompting", duration: "45 min" },
            { title: "Integrating LLMs with the AI SDK", duration: "55 min" },
            { title: "Streaming Responses", duration: "40 min" },
            { title: "Building Conversational Interfaces", duration: "50 min" },
          ],
        },
        {
          title: "Fine-tuning and Customization",
          lessons: [
            { title: "Introduction to Model Fine-tuning", duration: "40 min" },
            { title: "Preparing Training Data", duration: "45 min" },
            { title: "Fine-tuning Techniques", duration: "50 min" },
            { title: "Evaluating Fine-tuned Models", duration: "40 min" },
            { title: "Domain Adaptation Strategies", duration: "45 min" },
            { title: "Retrieval Augmented Generation (RAG)", duration: "55 min" },
            { title: "Building Custom Knowledge Bases", duration: "50 min" },
          ],
        },
        {
          title: "Building and Deploying AI Applications",
          lessons: [
            { title: "Designing AI-powered Applications", duration: "40 min" },
            { title: "Text Generation Applications", duration: "45 min" },
            { title: "Image Generation Integration", duration: "50 min" },
            { title: "Multimodal Applications", duration: "55 min" },
            { title: "Responsible AI Implementation", duration: "40 min" },
            { title: "Deployment and Scaling", duration: "45 min" },
            { title: "Building a Complete Generative AI Project", duration: "60 min" },
          ],
        },
      ],
      reviewCount: 42,
      reviews: [
        {
          name: "Samantha Lee",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "This course provided exactly what I needed to integrate generative AI into our product. The prompt engineering section alone was worth the price.",
        },
        {
          name: "Jason Miller",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "Comprehensive and practical. I've implemented several techniques from this course in production applications with great results.",
        },
        {
          name: "Priya Patel",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 4,
          comment:
            "Excellent content on a rapidly evolving field. The instructor keeps the material up-to-date and the projects are relevant to real-world applications.",
        },
      ],
      relatedCourses: [
        {
          title: "AI Agent Development",
          description: "Build autonomous AI agents that can perform complex tasks and solve problems.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$149",
          duration: "10 weeks",
          slug: "ai-agents",
        },
        {
          title: "Python Programming",
          description: "Learn Python for backend development, data analysis, and automation.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$89",
          duration: "8 weeks",
          slug: "python",
        },
        {
          title: "Next.js & React Masterclass",
          description: "Master React and Next.js to build modern, performant web applications.",
          image: "/placeholder.svg?height=200&width=350",
          price: "$99",
          duration: "8 weeks",
          slug: "nextjs-reactjs",
        },
      ],
    },
  }

  return courses[slug] || null
}
