"use client"

import Link from "next/link"
import { ArrowRight, Code, Cpu, Layers, Users, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import ProjectCard from "@/components/project-card"
import TestimonialCard from "@/components/testimonial-card"
import ContactForm from "@/components/contact-form"
import { motion } from "framer-motion"

export default function Home() {
  return (
    <main className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 md:py-28 bg-gradient-to-br from-blue-700 to-blue-900 text-white overflow-hidden dark:from-blue-900 dark:to-blue-950">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1600')] bg-center bg-no-repeat bg-cover opacity-10"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div
              className="md:w-1/2 mb-10 md:mb-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Building the <span className="text-blue-300">Future</span> with Code & AI
              </h1>
              <p className="text-xl mb-8 text-blue-100">
                Full-stack developer specializing in web development, generative AI integration, and building
                intelligent AI agents.
              </p>
              <div className="flex flex-wrap gap-4">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button size="lg" className="bg-white text-blue-700 hover:bg-blue-50">
                    View My Work <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Link href="/learn-skills">
                    <Button size="lg" variant="outline" className="border-white text-white hover:bg-blue-800">
                      Browse Skills <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </motion.div>
              </div>
            </motion.div>
            <motion.div
              className="md:w-1/2 flex justify-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="relative w-72 h-72 md:w-96 md:h-96 rounded-full bg-blue-500/20 flex items-center justify-center">
                <img
                  src="/placeholder.svg?height=400&width=400"
                  alt="Developer Profile"
                  className="rounded-full w-64 h-64 md:w-80 md:h-80 object-cover border-4 border-blue-400"
                />
                <motion.div
                  className="absolute -top-4 -right-4 bg-blue-500 text-white p-4 rounded-full"
                  animate={{
                    rotate: [0, 10, 0, -10, 0],
                  }}
                  transition={{
                    repeat: Number.POSITIVE_INFINITY,
                    duration: 5,
                    ease: "easeInOut",
                  }}
                >
                  <Cpu className="h-8 w-8" />
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-blue-50 dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-blue-900 dark:text-blue-100">Services I Offer</h2>
            <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Specialized solutions to help you build innovative digital products and enhance your online presence
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <motion.div
              className="bg-white dark:bg-slate-800 rounded-xl shadow-sm hover:shadow-md transition-all duration-300 border border-blue-100 dark:border-slate-700 overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className="h-3 bg-blue-500 w-full"></div>
              <div className="p-8">
                <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-lg w-fit mb-4">
                  <Code className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-blue-900 dark:text-blue-100">
                  Web Application Development
                </h3>
                <p className="text-slate-600 dark:text-slate-400 mb-4">
                  Creating responsive, modern web applications using React, Next.js, and other cutting-edge
                  technologies.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700 dark:text-slate-300">Single-page applications (SPAs)</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700 dark:text-slate-300">E-commerce platforms</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700 dark:text-slate-300">Custom web portals</span>
                  </li>
                </ul>
                <Link
                  href="/services"
                  className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                >
                  Learn More <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            </motion.div>

            <motion.div
              className="bg-white dark:bg-slate-800 rounded-xl shadow-sm hover:shadow-md transition-all duration-300 border border-blue-100 dark:border-slate-700 overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5 }}
            >
              <div className="h-3 bg-blue-500 w-full"></div>
              <div className="p-8">
                <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-lg w-fit mb-4">
                  <Cpu className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-blue-900 dark:text-blue-100">AI Integration</h3>
                <p className="text-slate-600 dark:text-slate-400 mb-4">
                  Integrating cutting-edge AI capabilities into your applications to enhance functionality and user
                  experience.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700 dark:text-slate-300">Generative AI implementation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700 dark:text-slate-300">Natural language processing</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700 dark:text-slate-300">Recommendation systems</span>
                  </li>
                </ul>
                <Link
                  href="/services"
                  className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                >
                  Learn More <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            </motion.div>

            <motion.div
              className="bg-white dark:bg-slate-800 rounded-xl shadow-sm hover:shadow-md transition-all duration-300 border border-blue-100 dark:border-slate-700 overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5 }}
            >
              <div className="h-3 bg-blue-500 w-full"></div>
              <div className="p-8">
                <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-lg w-fit mb-4">
                  <Layers className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-blue-900 dark:text-blue-100">AI Agent Development</h3>
                <p className="text-slate-600 dark:text-slate-400 mb-4">
                  Building autonomous AI agents that can perform complex tasks and solve real-world problems.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700 dark:text-slate-300">Autonomous agent architecture</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700 dark:text-slate-300">Task automation agents</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700 dark:text-slate-300">Conversational AI agents</span>
                  </li>
                </ul>
                <Link
                  href="/services"
                  className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                >
                  Learn More <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            </motion.div>
          </div>

          <motion.div
            className="text-center mt-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Link href="/services">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600">
                View All Services <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20 dark:bg-slate-950">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-blue-900 dark:text-blue-100">Featured Projects</h2>
            <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              A selection of my recent work across web and AI domains
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <ProjectCard
                title="AI-Powered Content Generator"
                description="A web application that uses GPT-4 to generate various types of content for marketing and creative purposes."
                image="/placeholder.svg?height=300&width=500"
                tags={["Next.js", "AI SDK", "Tailwind CSS"]}
                link="#"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <ProjectCard
                title="E-commerce Platform"
                description="A full-featured e-commerce platform with product management, cart functionality, and payment processing."
                image="/placeholder.svg?height=300&width=500"
                tags={["Next.js", "Stripe", "Supabase"]}
                link="#"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <ProjectCard
                title="Autonomous Trading Agent"
                description="An AI agent that analyzes market trends and executes trades based on predefined strategies."
                image="/placeholder.svg?height=300&width=500"
                tags={["Python", "TensorFlow", "API Integration"]}
                link="#"
              />
            </motion.div>
          </div>

          <motion.div
            className="text-center mt-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Link href="/projects">
              <Button
                variant="outline"
                size="lg"
                className="border-blue-500 text-blue-500 hover:bg-blue-50 dark:border-blue-700 dark:text-blue-400 dark:hover:bg-blue-950"
              >
                View All Projects <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-20 bg-gradient-to-r from-blue-700 to-blue-900 text-white dark:from-blue-900 dark:to-blue-950">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Learn From Me</h2>
            <p className="text-blue-100 max-w-2xl mx-auto">
              Comprehensive skills designed to help you master modern development and AI
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-all duration-300"
            >
              <div className="bg-blue-500/20 p-3 rounded-lg w-fit mb-4">
                <Code className="h-6 w-6 text-blue-100" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Web Development</h3>
              <p className="text-blue-100 mb-4">
                Learn HTML, CSS, JavaScript, and modern frameworks like React and Next.js.
              </p>
              <Link href="/learn-skills/web-development">
                <Button variant="outline" className="border-white text-white hover:bg-blue-800">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-all duration-300"
            >
              <div className="bg-blue-500/20 p-3 rounded-lg w-fit mb-4">
                <Cpu className="h-6 w-6 text-blue-100" />
              </div>
              <h3 className="text-xl font-semibold mb-2">AI Development</h3>
              <p className="text-blue-100 mb-4">
                Master AI integration, generative models, and building intelligent applications.
              </p>
              <Link href="/learn-skills/ai-agents">
                <Button variant="outline" className="border-white text-white hover:bg-blue-800">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-all duration-300"
            >
              <div className="bg-blue-500/20 p-3 rounded-lg w-fit mb-4">
                <Layers className="h-6 w-6 text-blue-100" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Python Programming</h3>
              <p className="text-blue-100 mb-4">Learn Python for backend development, data analysis, and automation.</p>
              <Link href="/learn-skills/python">
                <Button variant="outline" className="border-white text-white hover:bg-blue-800">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </motion.div>
          </div>

          <motion.div
            className="text-center mt-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Link href="/learn-skills">
              <Button className="bg-white text-blue-700 hover:bg-blue-50" size="lg">
                Browse All Skills <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-blue-50 dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-blue-900 dark:text-blue-100">
              What My Students Say
            </h2>
            <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Feedback from students who have taken my courses and applied their new skills
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <TestimonialCard
                name="Sarah Johnson"
                role="Frontend Developer"
                image="/placeholder.svg?height=100&width=100"
                testimonial="The web development course completely transformed my career. I went from struggling with basic concepts to confidently building complex applications."
                rating={5}
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <TestimonialCard
                name="Michael Chen"
                role="Full Stack Developer"
                image="/placeholder.svg?height=100&width=100"
                testimonial="Learning Next.js through this course was a game-changer. The hands-on projects helped me understand the concepts deeply."
                rating={5}
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <TestimonialCard
                name="Jessica Williams"
                role="AI Engineer"
                image="/placeholder.svg?height=100&width=100"
                testimonial="The AI course demystified complex concepts and made them accessible. I'm now building AI-powered applications I never thought I could create."
                rating={4}
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 dark:bg-slate-950">
        <div className="container mx-auto px-4">
          <motion.div
            className="max-w-4xl mx-auto bg-white dark:bg-slate-800 rounded-2xl shadow-lg overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/2 bg-gradient-to-br from-blue-700 to-blue-900 text-white p-10">
                <h2 className="text-3xl font-bold mb-6">Get In Touch</h2>
                <p className="mb-8 text-blue-100">
                  Interested in working together or have questions about my skills? Feel free to reach out!
                </p>

                <div className="space-y-4">
                  <div className="flex items-center">
                    <div className="bg-blue-800 p-3 rounded-full mr-4">
                      <Users className="h-5 w-5 text-blue-300" />
                    </div>
                    <div>
                      <h3 className="font-medium">Consulting</h3>
                      <p className="text-sm text-blue-200">Available for freelance projects</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="bg-blue-800 p-3 rounded-full mr-4">
                      <Code className="h-5 w-5 text-blue-300" />
                    </div>
                    <div>
                      <h3 className="font-medium">Development</h3>
                      <p className="text-sm text-blue-200">Web and AI solutions</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="bg-blue-800 p-3 rounded-full mr-4">
                      <Cpu className="h-5 w-5 text-blue-300" />
                    </div>
                    <div>
                      <h3 className="font-medium">Training</h3>
                      <p className="text-sm text-blue-200">Custom workshops and courses</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="md:w-1/2 p-10 dark:bg-slate-800">
                <ContactForm email="tawab05@gmail.com" />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-blue-700 to-blue-900 text-white py-12 dark:from-blue-900 dark:to-blue-950">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h2 className="text-2xl font-bold">Mustafa Dev</h2>
              <p className="text-blue-200 mt-2">Building the future with code and AI</p>
            </div>

            <div className="flex space-x-6">
              <Link href="#" className="hover:text-blue-300 transition-colors">
                Twitter
              </Link>
              <Link href="#" className="hover:text-blue-300 transition-colors">
                GitHub
              </Link>
              <Link href="#" className="hover:text-blue-300 transition-colors">
                LinkedIn
              </Link>
              <Link href="#" className="hover:text-blue-300 transition-colors">
                YouTube
              </Link>
            </div>
          </div>

          <div className="border-t border-blue-600 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-blue-200 text-sm">© {new Date().getFullYear()} Mustafa Dev. All rights reserved.</p>

            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="#" className="text-blue-200 hover:text-white text-sm">
                Privacy Policy
              </Link>
              <Link href="#" className="text-blue-200 hover:text-white text-sm">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </main>
  )
}
