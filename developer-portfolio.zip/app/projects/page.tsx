import { ArrowRight, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ProjectCard from "@/components/project-card"

export default function ProjectsPage() {
  const projects = [
    {
      title: "AI-Powered Content Generator",
      description:
        "A web application that uses GPT-4 to generate various types of content for marketing and creative purposes.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["Next.js", "AI SDK", "Tailwind CSS"],
      link: "#",
      category: "ai",
    },
    {
      title: "Cross-Platform Fitness App",
      description: "A mobile application for fitness tracking with personalized workout recommendations.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["React Native", "Firebase", "Health API"],
      link: "#",
      category: "mobile",
    },
    {
      title: "E-commerce Platform",
      description:
        "A full-featured e-commerce platform with product management, cart functionality, and payment processing.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["Next.js", "Stripe", "Supabase"],
      link: "#",
      category: "web",
    },
    {
      title: "Autonomous Trading Agent",
      description: "An AI agent that analyzes market trends and executes trades based on predefined strategies.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["Python", "TensorFlow", "API Integration"],
      link: "#",
      category: "ai",
    },
    {
      title: "Real Estate Listing Portal",
      description: "A web application for real estate listings with advanced search and filtering capabilities.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["Vue.js", "Node.js", "MongoDB"],
      link: "#",
      category: "web",
    },
    {
      title: "Inventory Management System",
      description: "A comprehensive inventory management system for small to medium-sized businesses.",
      image: "/placeholder.svg?height=300&width=500",
      tags: ["React", "Express", "PostgreSQL"],
      link: "#",
      category: "web",
    },
  ]

  return (
    <main className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-slate-900 text-white py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">My Projects</h1>
          <p className="text-xl text-slate-300 max-w-2xl">
            Explore my portfolio of web applications, mobile apps, and AI-powered solutions that solve real-world
            problems.
          </p>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="all">All Projects</TabsTrigger>
                <TabsTrigger value="web">Web</TabsTrigger>
                <TabsTrigger value="mobile">Mobile</TabsTrigger>
                <TabsTrigger value="ai">AI</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects.map((project, index) => (
                  <ProjectCard
                    key={index}
                    title={project.title}
                    description={project.description}
                    image={project.image}
                    tags={project.tags}
                    link={project.link}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="web" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "web")
                  .map((project, index) => (
                    <ProjectCard
                      key={index}
                      title={project.title}
                      description={project.description}
                      image={project.image}
                      tags={project.tags}
                      link={project.link}
                    />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="mobile" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "mobile")
                  .map((project, index) => (
                    <ProjectCard
                      key={index}
                      title={project.title}
                      description={project.description}
                      image={project.image}
                      tags={project.tags}
                      link={project.link}
                    />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="ai" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "ai")
                  .map((project, index) => (
                    <ProjectCard
                      key={index}
                      title={project.title}
                      description={project.description}
                      image={project.image}
                      tags={project.tags}
                      link={project.link}
                    />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-slate-50 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Interested in working together?</h2>
          <p className="text-slate-600 max-w-2xl mx-auto mb-8">
            I'm always open to discussing new projects, creative ideas, or opportunities to be part of your vision.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="bg-emerald-500 hover:bg-emerald-600">
              Contact Me <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline">
              View My Services <ExternalLink className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
