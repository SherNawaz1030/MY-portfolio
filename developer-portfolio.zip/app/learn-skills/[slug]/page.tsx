"use client"

import Link from "next/link"
import {
  ArrowLeft,
  BarChart,
  BookOpen,
  Calendar,
  CheckCircle,
  Clock,
  MessageCircle,
  Users,
  ArrowRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { motion } from "framer-motion"
import { useEffect } from "react"
import WhatsAppButton from "@/components/whatsapp-button"

interface SkillPageProps {
  params: {
    slug: string
  }
}

export default function SkillPage({ params }: SkillPageProps) {
  // This would typically come from a database or API
  const skillData = getSkillData(params.slug)

  // Scroll to top on page load
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [params.slug])

  if (!skillData) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-3xl font-bold mb-4 dark:text-white">Skill Not Found</h1>
        <p className="mb-8 dark:text-slate-300">The skill you're looking for doesn't exist.</p>
        <Link href="/learn-skills">
          <Button className="bg-blue-500 hover:bg-blue-600">Back to Skills</Button>
        </Link>
      </div>
    )
  }

  // Create WhatsApp message based on skill
  const whatsappMessage = `Hello! I'm interested in learning ${skillData.title}. Can you provide more information?`

  return (
    <main className="flex flex-col min-h-screen dark:bg-slate-950">
      {/* WhatsApp Button */}
      <WhatsAppButton phoneNumber="+1234567890" message={whatsappMessage} />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-700 to-blue-900 text-white py-20 dark:from-blue-900 dark:to-blue-950">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.3 }}>
            <Link href="/learn-skills" className="inline-flex items-center text-blue-100 hover:text-white mb-6">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Skills
            </Link>
          </motion.div>
          <motion.h1
            className="text-4xl md:text-5xl font-bold mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {skillData.title}
          </motion.h1>
          <motion.p
            className="text-xl text-blue-100 max-w-3xl mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            {skillData.description}
          </motion.p>
          <motion.div
            className="flex flex-wrap gap-6 mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center">
              <Clock className="h-5 w-5 mr-2 text-blue-300" />
              <span>{skillData.duration}</span>
            </div>
            <div className="flex items-center">
              <BarChart className="h-5 w-5 mr-2 text-blue-300" />
              <span>{skillData.level}</span>
            </div>
            <div className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-blue-300" />
              <span>{skillData.students}+ Students</span>
            </div>
            <div className="flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-blue-300" />
              <span>Last Updated: {skillData.lastUpdated}</span>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-wrap gap-4"
          >
            <Button size="lg" className="bg-white text-blue-700 hover:bg-blue-50">
              <Link href="/register">Enroll Now</Link>
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-blue-800">
              <Link
                href={`https://wa.me/1234567890?text=${encodeURIComponent(whatsappMessage)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center"
              >
                <MessageCircle className="mr-2 h-5 w-5" /> Chat on WhatsApp
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Skill Content Section */}
      <section className="py-16 dark:bg-slate-950">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-12">
            <motion.div
              className="lg:w-2/3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Tabs defaultValue="overview">
                <TabsList className="mb-8">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                  <TabsTrigger value="instructor">Instructor</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>

                <TabsContent value="overview">
                  <div>
                    <h2 className="text-2xl font-bold mb-6 text-blue-900 dark:text-blue-100">About This Skill</h2>
                    <div className="prose max-w-none dark:prose-invert">
                      <p className="mb-4 dark:text-slate-300">{skillData.longDescription}</p>

                      <h3 className="text-xl font-semibold mt-8 mb-4 text-blue-900 dark:text-blue-100">
                        What You'll Learn
                      </h3>
                      <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {skillData.learningOutcomes.map((outcome, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                            <span className="dark:text-slate-300">{outcome}</span>
                          </li>
                        ))}
                      </ul>

                      <h3 className="text-xl font-semibold mt-8 mb-4 text-blue-900 dark:text-blue-100">Requirements</h3>
                      <ul className="space-y-2">
                        {skillData.requirements.map((req, index) => (
                          <li key={index} className="flex items-start">
                            <span className="text-blue-500 mr-2">•</span>
                            <span className="dark:text-slate-300">{req}</span>
                          </li>
                        ))}
                      </ul>

                      <h3 className="text-xl font-semibold mt-8 mb-4 text-blue-900 dark:text-blue-100">
                        Who This Skill Is For
                      </h3>
                      <ul className="space-y-2">
                        {skillData.targetAudience.map((audience, index) => (
                          <li key={index} className="flex items-start">
                            <span className="text-blue-500 mr-2">•</span>
                            <span className="dark:text-slate-300">{audience}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="curriculum">
                  <div className="mt-8">
                    <h3 className="text-2xl font-bold mb-6 text-blue-900 dark:text-blue-100">Skill Curriculum</h3>

                    <div className="space-y-6">
                      {skillData.curriculum.map((module, index) => (
                        <div
                          key={index}
                          className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden"
                        >
                          <div className="bg-blue-50 dark:bg-blue-900/30 p-4 font-medium text-blue-900 dark:text-blue-100">
                            Module {index + 1}: {module.title}
                          </div>
                          <div className="p-4">
                            <ul className="space-y-3">
                              {module.lessons.map((lesson, lessonIndex) => (
                                <li key={lessonIndex} className="flex items-start">
                                  <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                                  <div className="flex justify-between w-full">
                                    <span className="dark:text-slate-300">{lesson.title}</span>
                                    <span className="text-sm text-slate-500 dark:text-slate-400">
                                      {lesson.duration}
                                    </span>
                                  </div>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="instructor">
                  <div>
                    <h2 className="text-2xl font-bold mb-6 text-blue-900 dark:text-blue-100">Your Instructor</h2>
                    <div className="flex items-start gap-6 mb-8">
                      <img
                        src="/placeholder.svg?height=150&width=150"
                        alt="Instructor"
                        className="w-24 h-24 rounded-full object-cover"
                      />
                      <div>
                        <h3 className="text-xl font-semibold text-blue-900 dark:text-blue-100">Mustafa</h3>
                        <p className="text-slate-600 dark:text-slate-400 mb-4">Professional Developer & Educator</p>
                        <p className="mb-4 dark:text-slate-300">
                          With over 10 years of experience in web and AI development, I've worked with startups and
                          Fortune 500 companies to build scalable, user-friendly applications. I'm passionate about
                          teaching and helping others develop their technical skills.
                        </p>
                        <div className="flex gap-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">10+</div>
                            <div className="text-sm text-slate-600 dark:text-slate-400">Years Experience</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">50+</div>
                            <div className="text-sm text-slate-600 dark:text-slate-400">Projects Completed</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">5,000+</div>
                            <div className="text-sm text-slate-600 dark:text-slate-400">Students Taught</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="reviews">
                  <div>
                    <h2 className="text-2xl font-bold mb-6 text-blue-900 dark:text-blue-100">Student Reviews</h2>
                    <div className="flex items-center mb-8">
                      <div className="text-5xl font-bold mr-6 text-blue-900 dark:text-blue-100">4.8</div>
                      <div>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <svg key={star} className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 24 24">
                              <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                            </svg>
                          ))}
                        </div>
                        <p className="text-slate-600 dark:text-slate-400">Based on {skillData.reviewCount} reviews</p>
                      </div>
                    </div>

                    <div className="space-y-6">
                      {skillData.reviews.map((review, index) => (
                        <div key={index} className="border-b border-slate-200 dark:border-slate-700 pb-6">
                          <div className="flex items-center mb-2">
                            <img
                              src={review.avatar || "/placeholder.svg?height=50&width=50"}
                              alt={review.name}
                              className="w-10 h-10 rounded-full mr-3"
                            />
                            <div>
                              <h4 className="font-medium text-blue-900 dark:text-blue-100">{review.name}</h4>
                              <div className="flex">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <svg
                                    key={star}
                                    className={`w-4 h-4 ${star <= review.rating ? "text-yellow-400" : "text-slate-300 dark:text-slate-600"} fill-current`}
                                    viewBox="0 0 24 24"
                                  >
                                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                                  </svg>
                                ))}
                              </div>
                            </div>
                          </div>
                          <p className="text-slate-600 dark:text-slate-300">{review.comment}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </motion.div>

            <motion.div
              className="lg:w-1/3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden sticky top-24">
                <img
                  src={skillData.image || "/placeholder.svg?height=300&width=500"}
                  alt={skillData.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="text-3xl font-bold mb-4 text-blue-900 dark:text-blue-100">Free Registration</div>

                  <div className="space-y-4 mb-6">
                    <div className="flex items-center">
                      <BookOpen className="h-5 w-5 text-slate-500 dark:text-slate-400 mr-3" />
                      <span className="dark:text-slate-300">
                        {skillData.curriculum.reduce((acc, module) => acc + module.lessons.length, 0)} lessons
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-slate-500 dark:text-slate-400 mr-3" />
                      <span className="dark:text-slate-300">{skillData.duration}</span>
                    </div>
                    <div className="flex items-center">
                      <Users className="h-5 w-5 text-slate-500 dark:text-slate-400 mr-3" />
                      <span className="dark:text-slate-300">Access on mobile and desktop</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-slate-500 dark:text-slate-400 mr-3" />
                      <span className="dark:text-slate-300">Certificate of completion</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Button className="w-full bg-blue-500 hover:bg-blue-600">
                      <Link href="/register" className="w-full">
                        Register Now
                      </Link>
                    </Button>

                    <Button
                      variant="outline"
                      className="w-full border-blue-500 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950 dark:text-blue-400 dark:border-blue-400"
                    >
                      <Link
                        href={`https://wa.me/1234567890?text=${encodeURIComponent(whatsappMessage)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full flex items-center justify-center"
                      >
                        <MessageCircle className="mr-2 h-5 w-5" /> Chat on WhatsApp
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Related Skills Section */}
      <section className="py-16 bg-blue-50 dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <motion.h2
            className="text-3xl font-bold mb-8 text-blue-900 dark:text-blue-100"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Related Skills
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {skillData.relatedSkills.map((skill, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <Link href={`/learn-skills/${skill.slug}`} className="block">
                  <div className="bg-white dark:bg-slate-800 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow h-full">
                    <img
                      src={skill.image || "/placeholder.svg?height=200&width=350"}
                      alt={skill.title}
                      className="w-full h-40 object-cover"
                    />
                    <div className="p-6">
                      <h3 className="text-xl font-semibold mb-2 text-blue-900 dark:text-blue-100">{skill.title}</h3>
                      <p className="text-slate-600 dark:text-slate-300 mb-4 line-clamp-2">{skill.description}</p>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center text-sm text-slate-500 dark:text-slate-400">
                          <Clock className="h-4 w-4 mr-1" />
                          {skill.duration}
                        </div>
                        <div className="flex items-center text-sm text-blue-500">
                          <span>Learn more</span>
                          <ArrowRight className="ml-1 h-4 w-4" />
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}

// This would typically come from a database or API
function getSkillData(slug) {
  const skills = {
    "web-development": {
      title: "Web Development Fundamentals",
      description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
      longDescription:
        "This comprehensive skill will take you from a complete beginner to a confident web developer. You'll learn the core technologies that power the web: HTML for structure, CSS for styling, and JavaScript for interactivity. Through hands-on projects and practical exercises, you'll build a strong foundation in web development principles and best practices that will serve as the basis for more advanced frameworks and libraries.",
      image: "/placeholder.svg?height=300&width=500",
      duration: "4 weeks",
      level: "Beginner",
      students: 1250,
      lastUpdated: "May 2025",
      learningOutcomes: [
        "Build responsive websites using HTML5 and CSS3",
        "Create interactive web pages with JavaScript",
        "Understand web development fundamentals and best practices",
        "Implement responsive design principles for mobile and desktop",
        "Use developer tools to debug and optimize websites",
        "Deploy websites to hosting platforms",
      ],
      requirements: [
        "No prior programming experience required",
        "Basic computer skills",
        "A computer with internet access",
        "Enthusiasm to learn and practice",
      ],
      targetAudience: [
        "Beginners with no prior coding experience",
        "Designers looking to expand their skills",
        "Anyone interested in learning web development",
        "Students preparing for more advanced web technologies",
      ],
      curriculum: [
        {
          title: "Introduction to HTML",
          lessons: [
            { title: "Web Development Overview", duration: "15 min" },
            { title: "HTML Document Structure", duration: "25 min" },
            { title: "Text Elements and Formatting", duration: "30 min" },
            { title: "Links and Navigation", duration: "20 min" },
            { title: "Images and Media", duration: "25 min" },
            { title: "Tables and Lists", duration: "30 min" },
            { title: "Forms and Input Elements", duration: "35 min" },
          ],
        },
        {
          title: "CSS Fundamentals",
          lessons: [
            { title: "Introduction to CSS", duration: "20 min" },
            { title: "Selectors and Properties", duration: "30 min" },
            { title: "Box Model and Layout", duration: "35 min" },
            { title: "Colors and Typography", duration: "25 min" },
            { title: "Flexbox Layout", duration: "40 min" },
            { title: "CSS Grid Layout", duration: "45 min" },
            { title: "Responsive Design Principles", duration: "35 min" },
          ],
        },
        {
          title: "JavaScript Basics",
          lessons: [
            { title: "Introduction to JavaScript", duration: "25 min" },
            { title: "Variables and Data Types", duration: "30 min" },
            { title: "Operators and Expressions", duration: "25 min" },
            { title: "Control Flow: Conditionals", duration: "35 min" },
            { title: "Control Flow: Loops", duration: "30 min" },
            { title: "Functions and Scope", duration: "40 min" },
            { title: "DOM Manipulation Basics", duration: "45 min" },
          ],
        },
        {
          title: "Building a Complete Website",
          lessons: [
            { title: "Project Planning and Setup", duration: "20 min" },
            { title: "Creating the HTML Structure", duration: "35 min" },
            { title: "Styling with CSS", duration: "40 min" },
            { title: "Adding Interactivity with JavaScript", duration: "45 min" },
            { title: "Responsive Design Implementation", duration: "35 min" },
            { title: "Testing and Debugging", duration: "30 min" },
            { title: "Deployment and Publishing", duration: "25 min" },
          ],
        },
      ],
      reviewCount: 128,
      reviews: [
        {
          name: "Sarah Johnson",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "This course was exactly what I needed as a complete beginner. The instructor explains everything clearly and the projects helped me apply what I learned.",
        },
        {
          name: "Michael Chen",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 4,
          comment:
            "Great introduction to web development. I feel confident in my HTML and CSS skills now, though I wish there was a bit more JavaScript content.",
        },
        {
          name: "Jessica Williams",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "The step-by-step approach made learning easy. I went from knowing nothing about coding to building my own portfolio website!",
        },
      ],
      relatedSkills: [
        {
          title: "React & Next.js Development",
          description: "Master React and Next.js to build modern, performant web applications.",
          image: "/placeholder.svg?height=200&width=350",
          duration: "8 weeks",
          slug: "nextjs-reactjs",
        },
        {
          title: "Vue.js Development",
          description: "Learn Vue.js to build reactive, component-based web applications.",
          image: "/placeholder.svg?height=200&width=350",
          duration: "6 weeks",
          slug: "vuejs",
        },
        {
          title: "Python Programming",
          description: "Learn Python for backend development, data analysis, and automation.",
          image: "/placeholder.svg?height=200&width=350",
          duration: "8 weeks",
          slug: "python",
        },
      ],
    },
    "nextjs-reactjs": {
      title: "React & Next.js Development",
      description: "Master React and Next.js to build modern, performant web applications.",
      longDescription:
        "Take your web development skills to the next level with this comprehensive skill on React and Next.js. You'll learn how to build modern, performant web applications using React's component-based architecture and Next.js's powerful features like server-side rendering, API routes, and more. By the end of this skill, you'll be able to create professional-grade web applications that are fast, scalable, and maintainable.",
      image: "/placeholder.svg?height=300&width=500",
      duration: "8 weeks",
      level: "Intermediate",
      students: 950,
      lastUpdated: "April 2025",
      learningOutcomes: [
        "Build modern web applications with React and Next.js",
        "Implement server-side rendering and static site generation",
        "Create and consume API routes in Next.js",
        "Manage state effectively in React applications",
        "Implement authentication and authorization",
        "Deploy Next.js applications to production",
      ],
      requirements: [
        "Basic knowledge of HTML, CSS, and JavaScript",
        "Understanding of ES6+ features",
        "Familiarity with npm and package management",
        "A computer with Node.js installed",
      ],
      targetAudience: [
        "Web developers looking to level up their skills",
        "Frontend developers wanting to learn React and Next.js",
        "Developers transitioning from other frameworks",
        "Students who have completed a web development basics course",
      ],
      curriculum: [
        {
          title: "React Fundamentals",
          lessons: [
            { title: "Introduction to React", duration: "30 min" },
            { title: "Components and Props", duration: "45 min" },
            { title: "State and Lifecycle", duration: "40 min" },
            { title: "Handling Events", duration: "35 min" },
            { title: "Conditional Rendering", duration: "30 min" },
            { title: "Lists and Keys", duration: "35 min" },
            { title: "Forms and Controlled Components", duration: "45 min" },
          ],
        },
        {
          title: "React Hooks",
          lessons: [
            { title: "Introduction to Hooks", duration: "25 min" },
            { title: "useState Hook", duration: "40 min" },
            { title: "useEffect Hook", duration: "45 min" },
            { title: "useContext Hook", duration: "35 min" },
            { title: "useRef Hook", duration: "30 min" },
            { title: "Custom Hooks", duration: "50 min" },
            { title: "Rules of Hooks", duration: "25 min" },
          ],
        },
        {
          title: "Next.js Fundamentals",
          lessons: [
            { title: "Introduction to Next.js", duration: "30 min" },
            { title: "Pages and Routing", duration: "40 min" },
            { title: "Data Fetching Methods", duration: "45 min" },
            { title: "Static Site Generation (SSG)", duration: "40 min" },
            { title: "Server-Side Rendering (SSR)", duration: "40 min" },
            { title: "API Routes", duration: "35 min" },
            { title: "Styling in Next.js", duration: "30 min" },
          ],
        },
        {
          title: "Building a Full Next.js Application",
          lessons: [
            { title: "Project Setup and Structure", duration: "25 min" },
            { title: "Authentication Implementation", duration: "50 min" },
            { title: "Database Integration", duration: "45 min" },
            { title: "Creating API Endpoints", duration: "40 min" },
            { title: "Building the Frontend", duration: "55 min" },
            { title: "Testing and Optimization", duration: "40 min" },
            { title: "Deployment to Vercel", duration: "30 min" },
          ],
        },
      ],
      reviewCount: 95,
      reviews: [
        {
          name: "David Kim",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "This course transformed my understanding of modern web development. The Next.js content is particularly valuable and up-to-date.",
        },
        {
          name: "Emily Rodriguez",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 5,
          comment:
            "Excellent course! I was able to build and deploy a production-ready application by following along with the projects.",
        },
        {
          name: "Alex Thompson",
          avatar: "/placeholder.svg?height=50&width=50",
          rating: 4,
          comment:
            "Great content and well-explained concepts. The only reason I'm not giving 5 stars is that I wish there was more content on state management libraries.",
        },
      ],
      relatedSkills: [
        {
          title: "Web Development Fundamentals",
          description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
          image: "/placeholder.svg?height=200&width=350",
          duration: "4 weeks",
          slug: "web-development",
        },
        {
          title: "Vue.js Development",
          description: "Learn Vue.js to build reactive, component-based web applications.",
          image: "/placeholder.svg?height=200&width=350",
          duration: "6 weeks",
          slug: "vuejs",
        },
        {
          title: "AI Agent Development",
          description: "Build autonomous AI agents that can perform complex tasks and solve problems.",
          image: "/placeholder.svg?height=200&width=350",
          duration: "10 weeks",
          slug: "ai-agents",
        },
      ],
    },
    // Add more skills here following the same pattern
  }

  return skills[slug] || null
}
