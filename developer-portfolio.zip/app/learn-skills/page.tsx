"use client"

import Link from "next/link"
import { ArrowRight, BookOpen, CheckCircle, Clock, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"

export default function LearnSkillsPage() {
  const skills = [
    {
      title: "Web Development Fundamentals",
      description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
      icon: <BookOpen className="h-6 w-6 text-blue-600" />,
      level: "Beginner",
      duration: "4 weeks",
      topics: ["HTML5", "CSS3", "JavaScript Basics", "Responsive Design", "Web Accessibility"],
      slug: "web-development",
    },
    {
      title: "React & Next.js Development",
      description: "Master React and Next.js to build modern, performant web applications.",
      icon: <BookOpen className="h-6 w-6 text-blue-600" />,
      level: "Intermediate",
      duration: "8 weeks",
      topics: [
        "React Fundamentals",
        "Hooks & State Management",
        "Next.js App Router",
        "Server Components",
        "API Integration",
      ],
      slug: "nextjs-reactjs",
    },
    {
      title: "Vue.js Development",
      description: "Learn Vue.js to build reactive, component-based web applications.",
      icon: <BookOpen className="h-6 w-6 text-blue-600" />,
      level: "Intermediate",
      duration: "6 weeks",
      topics: ["Vue.js Fundamentals", "Vue Router", "Vuex", "Composition API", "Vue 3 Features"],
      slug: "vuejs",
    },
    {
      title: "Quasar Framework",
      description: "Build high-performance Vue.js applications with the Quasar Framework.",
      icon: <BookOpen className="h-6 w-6 text-blue-600" />,
      level: "Intermediate",
      duration: "5 weeks",
      topics: ["Quasar CLI", "UI Components", "Layouts", "Quasar Plugins", "Mobile Development"],
      slug: "quasar-framework",
    },
    {
      title: "Python Programming",
      description: "Learn Python for backend development, data analysis, and automation.",
      icon: <BookOpen className="h-6 w-6 text-blue-600" />,
      level: "Beginner to Intermediate",
      duration: "8 weeks",
      topics: ["Python Basics", "Data Structures", "OOP in Python", "Web Scraping", "API Development"],
      slug: "python",
    },
    {
      title: "AI Agent Development",
      description: "Build autonomous AI agents that can perform complex tasks and solve problems.",
      icon: <BookOpen className="h-6 w-6 text-blue-600" />,
      level: "Advanced",
      duration: "10 weeks",
      topics: ["Agent Architecture", "LLM Integration", "Tool Use", "Memory Systems", "Multi-agent Systems"],
      slug: "ai-agents",
    },
    {
      title: "Generative AI Integration",
      description: "Learn to integrate and fine-tune generative AI models in your applications.",
      icon: <BookOpen className="h-6 w-6 text-blue-600" />,
      level: "Advanced",
      duration: "8 weeks",
      topics: ["LLM Fundamentals", "Prompt Engineering", "AI SDK", "Fine-tuning Models", "Multimodal AI"],
      slug: "generative-ai",
    },
  ]

  return (
    <main className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-700 to-blue-900 text-white py-20">
        <div className="container mx-auto px-4">
          <motion.h1
            className="text-4xl md:text-5xl font-bold mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Learn In-Demand Skills
          </motion.h1>
          <motion.p
            className="text-xl text-blue-100 max-w-2xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Master the technologies and skills that will help you build innovative applications and advance your career.
          </motion.p>
        </div>
      </section>

      {/* Skills Overview Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold mb-4 text-blue-900 dark:text-blue-100">Skills You Can Learn</h2>
            <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Comprehensive learning paths designed to help you master modern development and AI skills
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skills.map((skill, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <Card className="border-slate-200 hover:shadow-md transition-shadow h-full dark:border-slate-700">
                  <CardHeader>
                    <div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-lg w-fit mb-4">{skill.icon}</div>
                    <CardTitle className="text-blue-900 dark:text-blue-100">{skill.title}</CardTitle>
                    <CardDescription>{skill.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 mb-4 text-sm text-slate-600 dark:text-slate-400">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 mr-1 text-amber-500" />
                        {skill.level}
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1 text-slate-500 dark:text-slate-400" />
                        {skill.duration}
                      </div>
                    </div>
                    <h4 className="font-medium mb-2 text-blue-900 dark:text-blue-100">What you'll learn:</h4>
                    <ul className="space-y-1">
                      {skill.topics.map((topic, i) => (
                        <li key={i} className="flex items-start text-sm">
                          <CheckCircle className="h-4 w-4 mr-2 text-blue-500 mt-0.5" />
                          <span className="dark:text-slate-300">{topic}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Link href={`/learn-skills/${skill.slug}`} className="w-full">
                      <Button className="w-full bg-blue-500 hover:bg-blue-600">
                        View Details <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Learning Approach Section */}
      <section className="py-16 bg-blue-50 dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold mb-4 text-blue-900 dark:text-blue-100">My Teaching Approach</h2>
            <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Learn through a combination of theory, practical examples, and hands-on projects
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              className="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-sm text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="bg-blue-100 dark:bg-blue-900/30 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <BookOpen className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-blue-900 dark:text-blue-100">Comprehensive Curriculum</h3>
              <p className="text-slate-600 dark:text-slate-400">
                Structured learning paths that cover both fundamentals and advanced concepts, ensuring a solid
                understanding of the subject matter.
              </p>
            </motion.div>

            <motion.div
              className="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-sm text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="bg-blue-100 dark:bg-blue-900/30 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-blue-900 dark:text-blue-100">Practical Projects</h3>
              <p className="text-slate-600 dark:text-slate-400">
                Learn by doing with real-world projects that reinforce concepts and build your portfolio while you
                learn.
              </p>
            </motion.div>

            <motion.div
              className="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-sm text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="bg-blue-100 dark:bg-blue-900/30 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-blue-900 dark:text-blue-100">Industry Best Practices</h3>
              <p className="text-slate-600 dark:text-slate-400">
                Learn not just how to code, but how to write clean, maintainable code following industry standards and
                best practices.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-700 to-blue-900 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <motion.h2
            className="text-3xl font-bold mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Ready to start learning?
          </motion.h2>
          <motion.p
            className="text-blue-100 max-w-2xl mx-auto mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Browse our skills and start your journey to becoming a skilled developer today.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button size="lg" className="bg-white text-blue-700 hover:bg-blue-50">
              Register Now <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </motion.div>
        </div>
      </section>
    </main>
  )
}
