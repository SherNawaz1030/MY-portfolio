"use server"

import { Resend } from "resend"

interface EmailData {
  name: string
  email: string
  message: string
  recipientEmail: string
}

export async function sendEmail({ name, email, message, recipientEmail }: EmailData) {
  try {
    // Check if the API key exists
    const apiKey = process.env.RESEND_API_KEY

    if (!apiKey) {
      console.error("Missing Resend API key")
      return {
        success: false,
        error: "Configuration error: Missing API key",
      }
    }

    const resend = new Resend(apiKey)

    const { data, error } = await resend.emails.send({
      from: "Contact Form <onboarding@resend.dev>",
      to: [recipientEmail],
      subject: `New message from ${name}`,
      reply_to: email,
      text: `Name: ${name}\nEmail: ${email}\n\nMessage: ${message}`,
      html: `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #10b981; font-size: 24px; margin-bottom: 16px;">New Contact Form Submission</h2>
          <p style="margin-bottom: 8px;"><strong>Name:</strong> ${name}</p>
          <p style="margin-bottom: 8px;"><strong>Email:</strong> ${email}</p>
          <div style="margin-top: 24px;">
            <h3 style="font-size: 18px; margin-bottom: 8px;">Message:</h3>
            <p style="white-space: pre-line; background-color: #f3f4f6; padding: 16px; border-radius: 4px;">${message}</p>
          </div>
        </div>
      `,
    })

    if (error) {
      console.error("Error sending email:", error)
      return { success: false, error: error.message }
    }

    return { success: true, data }
  } catch (error) {
    console.error("Error sending email:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "An unknown error occurred",
    }
  }
}
