"use client"

import { useAuth } from "@/context/auth-context"
import AdminSidebar from "@/components/admin/sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Users, FileText, GraduationCap, MessageSquare, TrendingUp, Eye } from "lucide-react"
import { motion } from "framer-motion"

export default function AdminDashboardPage() {
  const { user } = useAuth()

  const stats = [
    { title: "Total Users", value: "1,234", icon: Users, color: "bg-blue-500" },
    { title: "Total Skills", value: "7", icon: GraduationCap, color: "bg-green-500" },
    { title: "Total Projects", value: "12", icon: FileText, color: "bg-amber-500" },
    { title: "Total Messages", value: "48", icon: MessageSquare, color: "bg-purple-500" },
  ]

  const recentActivities = [
    { action: "New user registered", time: "5 minutes ago" },
    { action: "New message received", time: "1 hour ago" },
    { action: "Project updated", time: "3 hours ago" },
    { action: "Skill content edited", time: "5 hours ago" },
    { action: "New testimonial added", time: "1 day ago" },
  ]

  return (
    <>
      <AdminSidebar />
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto">
          <motion.h1
            className="text-3xl font-bold text-blue-900 dark:text-white mb-2"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            Welcome back, {user?.name}
          </motion.h1>
          <motion.p
            className="text-slate-600 dark:text-slate-400 mb-8"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            Here's what's happening with your portfolio website today.
          </motion.p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Card>
                    <CardContent className="p-6 flex items-center">
                      <div className={`${stat.color} p-3 rounded-lg mr-4`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{stat.title}</p>
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{stat.value}</h3>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <motion.div
              className="lg:col-span-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart className="h-5 w-5 mr-2 text-blue-500" />
                    Website Analytics
                  </CardTitle>
                  <CardDescription>Website traffic over the last 30 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80 flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-md">
                    <p className="text-slate-500 dark:text-slate-400 flex items-center">
                      <TrendingUp className="h-5 w-5 mr-2 text-blue-500" />
                      Analytics chart will appear here
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Eye className="h-5 w-5 mr-2 text-blue-500" />
                    Recent Activity
                  </CardTitle>
                  <CardDescription>Latest updates and actions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivities.map((activity, index) => (
                      <div key={index} className="flex items-start">
                        <div className="h-2 w-2 mt-2 rounded-full bg-blue-500 mr-3"></div>
                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">{activity.action}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  )
}
