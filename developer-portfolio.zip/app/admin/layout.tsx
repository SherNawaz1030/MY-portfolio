import type React from "react"
import ProtectedRoute from "@/components/protected-route"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Admin Dashboard - Mustafa Dev",
  description: "Admin dashboard for managing website content",
}

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ProtectedRoute>
      <div className="flex min-h-screen bg-blue-50 dark:bg-slate-900">{children}</div>
    </ProtectedRoute>
  )
}
