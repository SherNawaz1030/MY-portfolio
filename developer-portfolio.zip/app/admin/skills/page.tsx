"use client"

import AdminSidebar from "@/components/admin/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Pencil, Trash2, MoreHorizontal, GraduationCap } from "lucide-react"
import { motion } from "framer-motion"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function AdminSkillsPage() {
  const skills = [
    {
      id: "1",
      title: "Web Development Fundamentals",
      description: "Learn HTML, CSS, and JavaScript to build the foundation of modern web development.",
      students: 1250,
      level: "Beginner",
    },
    {
      id: "2",
      title: "React & Next.js Development",
      description: "Master React and Next.js to build modern, performant web applications.",
      students: 950,
      level: "Intermediate",
    },
    {
      id: "3",
      title: "Vue.js Development",
      description: "Learn Vue.js to build reactive, component-based web applications.",
      students: 780,
      level: "Intermediate",
    },
    {
      id: "4",
      title: "Python Programming",
      description: "Learn Python for backend development, data analysis, and automation.",
      students: 1100,
      level: "Beginner to Intermediate",
    },
  ]

  return (
    <>
      <AdminSidebar />
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <motion.h1
              className="text-3xl font-bold text-blue-900 dark:text-white"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              Skills Management
            </motion.h1>
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Button className="bg-blue-500 hover:bg-blue-600">
                <Plus className="h-4 w-4 mr-2" />
                Add New Skill
              </Button>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {skills.map((skill, index) => (
              <motion.div
                key={skill.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center">
                        <div className="bg-blue-100 dark:bg-blue-900/30 p-2 rounded-lg mr-4">
                          <GraduationCap className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                        </div>
                        <CardTitle>{skill.title}</CardTitle>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Actions</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem className="flex items-center">
                            <Pencil className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem className="flex items-center text-red-600 dark:text-red-400">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600 dark:text-slate-400 mb-4">{skill.description}</p>
                    <div className="flex flex-wrap gap-4 text-sm">
                      <div className="flex items-center">
                        <span className="font-medium text-slate-700 dark:text-slate-300 mr-1">Level:</span>
                        <span className="text-slate-600 dark:text-slate-400">{skill.level}</span>
                      </div>
                      <div className="flex items-center">
                        <span className="font-medium text-slate-700 dark:text-slate-300 mr-1">Students:</span>
                        <span className="text-slate-600 dark:text-slate-400">{skill.students}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}
